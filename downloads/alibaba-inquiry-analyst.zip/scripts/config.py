"""
alibaba-inquiry-analyst / config.py
====================================
Global runtime configuration constants.
"""

LIST_TIMEOUT_MS = 25000
DETAIL_TIMEOUT_MS = 20000
SELECTOR_TIMEOUT_MS = 10000

WAIT_AFTER_NAV_MS = 1500
WAIT_DETAIL_RENDER_MS = 5000

MAX_INQUIRIES = 300
MAX_PAGES = 15
DEFAULT_MAX_DETAIL = 300

EXPORT_PDF_ENV = "ACCIO_EXPORT_PDF"
DEFAULT_EXPORT_PDF = False
EXPORT_MARKDOWN_ENV = "ACCIO_EXPORT_MARKDOWN"
DEFAULT_EXPORT_MARKDOWN = False

USER_LEVEL_ICON_MAP = {
    "O1CN01QPXkVq1xUmP6u0guh": "L1",
    "O1CN01irT4ui1PgVUnXIuXT": "L1+",
    "O1CN01NQDNGN1GXxg1QhmCW": "L2",
    "O1CN016s9YtC1jJsEn1Insi": "L3",
    "O1CN01Y2kXyK27mJc8CmtgL": "L4",
}

DEPTH_CONFIG = {
    "quick": {
        "max_scroll": 0,
        "description": "Quick mode: only currently visible messages (about 5-10 items).",
    },
    "normal": {
        "max_scroll": 3,
        "description": "Normal mode: scroll 3 times for recent messages (about 20-40 items).",
    },
    "full": {
        "max_scroll": -1,
        "description": "Full mode: scroll to the start and load complete history.",
    },
}
