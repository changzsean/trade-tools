# 登录态清理参考

> 适用场景：切换账号、清空自动登录状态、排查旧账号 session 残留。

## 执行命令

```powershell
python -X utf8 scripts\scrape_inquiries.py --clear-login-state
```

## 行为说明

- 该命令只删除已保存的自动登录 cookie，然后退出。
- 它不会抓取询盘，不会刷新负责人缓存，也不会写入 `inquiries.json`。
- 返回 JSON 中的 `status` 为 `ok`，`login_state` 为 `cleared` 或 `missing`。

## 抓取中跳转登录页

- 如果消息中心打开后跳转到 `https://login.alibaba.com/`，抓取脚本会立即返回 `LOGIN_REQUIRED` 并取消本轮抓取。
- Accio Work 应提示用户在新打开的浏览器里完成阿里国际站登录，然后重新运行查询。
- 该状态下不要读取旧 `inquiries.json`，不要生成报告，也不要自动重试同一请求。

## 适用时机

- 用户要求切换到另一个阿里国际站账号。
- 自动登录 cookie 损坏，导致进入错误账号或无法复用既有登录态。
- 需要明确丢弃本地保存的自动登录状态，再重新登录。

## 注意事项

- 若 CDP Chrome 仍保持旧账号会话，仅清 cookie 不一定会立刻切换账号。
- 遇到旧会话残留时，先关闭当前 CDP Chrome，或在网页里手动退出旧账号，再重新登录新账号。
- 这是登录态维护动作，不是抓取动作；不要和历史抓取、负责人刷新或报告生成混在同一条流程里。
