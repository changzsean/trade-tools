# 买家名称搜索参考

适用场景：

- 用户按买家名、发件人名、`senderName` 查询询盘

## 基本命令

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --buyer-name "Loretta Paulus"
```

后续用 `status` 单独轮询；`status` 显示可报告后单独运行 `finish`。不要把 `start` 和 `status` / `finish` / `watch` 串在同一次 Bash 调用里。

未显式给时间窗时：

- 服务端使用买家名搜索入口
- 后台默认范围为最近一年
- 输出中的 `scope_desc` 应描述为“最近一年买家名称=... 的询盘”

## 与时间窗组合

显式时间窗与买家名一起用时：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --buyer-name "Loretta Paulus" --start-time 2026-04-23 --end-time 2026-04-26
```

规则：

- URL 层只用 `senderName`
- 时间范围在本地按 `create_time` 再过滤
- 不把 `senderName` 和 `startTime` / `endTime` 拼进同一个搜索 payload

## 输出校验

买家名搜索结果至少要确认：

- `filter_buyer_name` 正确
- `scope_desc` 正确
- 如有显式时间窗，则 `start_time` / `end_time` 正确
