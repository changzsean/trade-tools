# 阿里国际站完整询盘报告

> 生成时间：{generated_at}
> 统计日期：{report_date}
> 数据来源：阿里国际站卖家后台

{actual_window_notice}
{freshness_notice}
---

## 1. 总览统计
{summary_bullets}

## 2. 商机类型
{business_type_bullets}

{previous_day_comparison}

## 3. 负责人跟进看板
| 负责人 | 总数 | 已回复 | 待回复 | 未回复 | 未知 |
|--------|------|--------|--------|--------|------|
{assignee_followup_table}

## 4. 待跟进重点
{followup_bullets}

## 5. 全量询盘明细（按询盘列表不去重抓取展示）
> 以下是结构化底稿。最终面向用户回复时，每条询盘都要保留，并把“摘要素材”改写为 1-2 句自然中文业务摘要。

{inquiry_detail_cards}

## 6. 数据完整性说明
{data_quality_notes}

{report_file_links}

---
*本报告由 Accio 自动生成 · 数据来源：阿里国际站卖家后台 · {generated_at}*
