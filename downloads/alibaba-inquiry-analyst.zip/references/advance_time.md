# 历史时间窗参考

适用场景：

- 用户明确给出 `--start-time` / `--end-time`
- 查询昨日、上周、某个历史区间
- 需要长时间窗批处理

## 唯一入口

Accio Work 统一使用 manager，不直接运行 `scrape_inquiries.py`：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time 2026-04-23 --end-time 2026-04-26
```

`start` 必须单独运行。后续用 `status` 轮询，status 返回可报告后再单独运行 `finish`；也可在 Bash 工具调用显式设置了足够长超时时再单独运行 `watch --force --max-minutes auto`。

长时间窗同样走 manager：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time 2026-04-01 --end-time 2026-04-16
```

## 时间窗语义

- `start_time` 为包含边界
- `end_time` 为排他边界
- 用户口语里的闭区间，要先换算成脚本的半开区间

例子：

- 只查 `2026-04-23`:
  `--start-time 2026-04-23 --end-time 2026-04-24`
- 查 `2026-04-23` 到 `2026-04-25`:
  `--start-time 2026-04-23 --end-time 2026-04-26`

## 行为规则

- 历史范围不再使用旧日期简写参数
- 默认详情和列表都不设上限，除非用户显式限制
- 时间窗超过 7 天时，可自动按 `--chunk-days` 做内部切片
- 时间窗超过 5 天时，详情页抓取会自动放慢开 tab 节奏
- Bash 工具 120 秒超时时，不读取旧结果、不生成报告；继续运行 manager `status`，完成后运行 `finish`，或在单独的长超时工具调用里运行 `watch --force --max-minutes auto`
- 禁止把 `start` 和 `status` / `finish` / `watch` 用 `&&`、`;` 或同一个 shell 调用串联
- 短超时 agent shell 里未加 `--force` 的 watch 会返回 `blocked`，这时继续 `status` / `finish`
- manager 返回 `watch_timeout` 时说明抓取进程可能仍在后台运行，只继续 watch/status，不重新 start

## 输出校验

历史结果应以这些字段为准：

- `mode`
- `scope_desc`
- `start_time`
- `end_time`
- `total`
- `detail_count`
- `detail_skipped`

`date` 只是落盘日期，不代表统计窗口日期。
