# 列表入口与选择器参考

## 列表入口

当前只保留三类中性入口：

| 场景 | 说明 |
| --- | --- |
| 默认列表入口 | `https://message.alibaba.com/message/default.htm#feedback/all` |
| 高级时间窗入口 | 使用 `search={"startTime":"...","endTime":"..."}` |
| 买家名搜索入口 | 使用 `search={"senderName":"..."}` |

负责人 URL 过滤仅在默认列表入口稳定；时间窗查询默认仍走本地负责人过滤。

## 跳转方式

统一使用：

```javascript
window.location.href = url
```

不要再把旧排序 URL 参数当成可靠排序控制。

## 主要选择器

| 用途 | 选择器 |
| --- | --- |
| 列表项 | `[class*='inquiry-item']` |
| 询盘 ID | `[class*='spec-inquiry-id']` |
| 时间行 | `[class*='m-header-padding']:not([class*='spec-inquiry'])` |
| 买家名 | `.aui2-grid-name` |
| 产品名 | `.buyer-product-name-content` |
| 最新消息 | `.buyer-chat-msg` |
| 分类 | `[class*='aui-grid-category']` |
| 负责人 | `[class*='owner-name'], .aui2-grid-owner .aui-menu-trigger, [class*='owner'] [class*='name']` |
| 国旗/国家 | `.ui2-flag` |
| 买家等级图标 | `.spec-icon-wrap .aui-icon-buyer-level, .spec-icon-wrap .level-tag-icon` |

## 时间字段口径

列表时间行仍然同时暴露：

- `update_time`
- `create_time`

但新模型只把 `create_time` 当作时间窗过滤口径。
