---
name: alibaba-inquiry-analyst
description: "Alibaba.com Inquiry Analyst. Scrapes and deeply analyzes store inquiries and TM messages. Supports filtering by time, assignee, and buyer name, generating complete business reports with conversion analysis and salesperson dashboards."
---

# Alibaba.com Inquiry Analyst

## 环境要求

| 项目 | 配置 |
| --- | --- |
| Python | 3.9+ |
| Playwright | 1.58.0+ |
| Chrome CDP | `localhost:9222` |

Accio Work 运行命令时优先使用 UTF-8。公开入口统一使用 manager。
运行 `scripts\accio_scrape_manager.py` 前必须先进入本 skill 根目录，或使用本 skill 根目录下脚本的绝对路径；不要在 Accio agent 临时 `project` 目录中用相对路径执行，否则会找不到 `scripts\accio_scrape_manager.py`。
`start` 必须单独作为一次工具调用运行，禁止和 `status` / `finish` / `watch` 用 `&&`、`;` 或同一个 shell 调用串联：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time <开始毫秒时间戳> --end-time <结束毫秒时间戳>
```

`start` 返回后，默认运行 `wait` 等待；若 `wait` 返回 `status=running`，继续运行 `wait`，不要回到高频 `status` 轮询。`wait` 返回 `completed` 后直接展示报告结果，禁止再读日志、列目录、查进程或重复 `wait/status`。`status` 仅用于诊断；`finish` 仅用于兼容/人工修复收尾。默认不要使用 `watch --force`、`sleep`、`timeout` 或 `python -c "time.sleep(...)"` 等长等待命令，因为工具层超时会让会话看起来卡死。`watch --force --max-minutes auto` 只有在运行器通过 `ACCIO_TOOL_TIMEOUT_SECONDS` / `ACCIO_BASH_TIMEOUT_SECONDS` / `CODEX_TOOL_TIMEOUT_SECONDS` 明确提供足够长的工具超时时才会真正长等：

```powershell
python -X utf8 scripts\accio_scrape_manager.py wait
```

诊断/兼容路径：

```powershell
python -X utf8 scripts\accio_scrape_manager.py status
python -X utf8 scripts\accio_scrape_manager.py finish
```

明确长超时 runner 可使用：

```powershell
python -X utf8 scripts\accio_scrape_manager.py watch --force --max-minutes auto
```

## 必读文件

每次生成面向用户的询盘报告前必须读取：

1. `references/reporting.md`
2. `references/report_template.md`

## 报告输出纪律

- Accio Work 运行时，`inquiries.json`、抓取日志和 `outputs/runtime/accio_scrape_state.json` 继续保留在本 skill 根目录，用于校验本轮抓取链路；不要用共享工作区里的旧报告反推本轮抓取数据。
- Markdown / PDF 导出都由配置控制，默认关闭：`scripts/config.py` 中 `DEFAULT_EXPORT_MARKDOWN = False`、`DEFAULT_EXPORT_PDF = False`。需要启用 Markdown 文件时可运行报告脚本加 `--md`，或设置 `ACCIO_EXPORT_MARKDOWN=1`；需要启用 PDF 时可加 `--pdf`，或设置 `ACCIO_EXPORT_PDF=1`。
- 文件导出关闭时，最终回复不得包含 `## 报告文件`、Markdown/PDF 链接、文件路径或未生成提示等交付物内容。报告脚本会返回 `report_text`，若正文太长导致 stdout 省略，则必须读取 `report_text_path` 指向的内部正文文件后再回复；该内部路径只用于读取，不得展示给用户。
- 启用文件导出时，报告默认输出到 Agent 共享工作区的专属子目录 `alibaba-inquiry-analyst-output`。manager 会按 `--report-output-dir`、state、`ACCIO_REPORT_OUTPUT_DIR`、`ACCIO_PROJECT_DIR\alibaba-inquiry-analyst-output`、skill 根目录的顺序解析报告目录。
- `report_text_path` 是上游 skill 给 Accio Work 或下游 skill 的内部交接文件，不是用户交付物。下游调用本 skill 时，如果 manager JSON 返回 `report_text_omitted=true`，必须在 72 小时内读取 `report_text_path` 获取完整正文；不得把该路径输出给用户，不得把它当 Markdown/PDF 报告链接。如果路径已不存在或读取失败，必须重新调用 manager 生成报告，不能根据旧 JSON 或记忆补写。

- 用户说“查询/查一下/抓取/看一下/今日询盘/今日单独询盘/昨日询盘”等查询类请求时，必须先运行 `scripts\accio_scrape_manager.py start` 启动目标时间窗抓取，再运行独立的 `scripts\accio_scrape_manager.py wait`。若 `wait` 返回 `running`，继续运行 `wait`；`wait=completed` 后直接输出报告，不要再跑 `finish`。`status` 仅用于诊断；默认不要用 `watch --force` 或 shell sleep 等待。没有 manager 成功产物，就禁止输出报告。
- `scripts\scrape_inquiries.py` 是 manager 的内部抓取脚本；Accio Work 不直接运行它作为查询入口。
- `scripts\accio_generate_report.py` 只能在本轮抓取成功之后运行，不能直接消费旧的 `inquiries.json` 当作本次查询结果。
- 如果 Chrome CDP 未连接、登录态失效、抓取命令失败或无法确认 `inquiries.json` 是本轮新生成的，必须停止并报告阻塞原因，不能根据记忆、旧文件或推断生成“0 条”报告。
- Accio Work 面向用户的默认输出是完整报告，但排版采用 Accio Work 风格业务汇报，不直接粘贴宽 Markdown 表格。
- 用户说“报告”“完整列表”“完整报告”“列表”“统计”“分析”或抓取完成后需要反馈结果时，必须按 `references/reporting.md` 运行 `scripts\accio_generate_report.py`，再基于本轮 `report_text` 或 `report_text_path` 的完整结构化底稿输出 1-6 模块正文。
- 不临时手写简约表格替代正式报告；不只输出少数字段列表；不只给总数或摘要后结束；不要写“以下是报告摘要”后省略第 5 模块。
- 如果报告顶部包含“当前中国时间尚未到达本次统计窗口结束时间”的提示，最终面向用户的报告必须保留该提示；该提示由报告脚本优先使用 Apple 时间服务器、失败后回退本机时间生成。
- 完整报告必须包含总览统计、商机类型、负责人跟进看板、待跟进重点、全量询盘明细和数据完整性说明。
- 负责人跟进看板只能使用 `scripts\accio_generate_report.py` 返回的 `report_text` 第 3 模块原表格，或同一个 JSON payload 里的 `assignee_followup` 结构化字段；禁止从全量询盘明细的买家标题/买家名/对话内容重新聚合，否则容易把买家名误当负责人。
- 全量询盘明细必须展示每一条询盘。每条用卡片/小节形式展示基本信息、前五句对话，并由模型生成 1-2 句自然业务摘要；禁止只展示前几条和最后一条。
- 只有本轮启用 Markdown 或 PDF 导出时，最终回复末尾才保留 `## 报告文件` 区块，并使用 Accio Work 可直接点击打开的 `file:///` 链接。Markdown 链接格式统一为 `[📄 打开 Markdown 报告](file:///path/to/project/alibaba-inquiry-analyst-output/report.md)`
；PDF 只有本轮明确启用且成功生成时才额外出现。文件导出关闭时不要输出报告文件区块。
- 只有用户明确要求“只要简版/只要一句话/不要完整报告”时，才可以额外给简版。

## 最终回复前检查清单

向用户输出最终答复前，必须逐项检查：

1. 已完成 `start -> status -> finish`；如果是在本地终端/CI 长超时 runner 中，也可接受 `watch --force --max-minutes auto` 已成功完成；`status == "ok"`，且 manager 校验 `reportable == true`。
2. 最终报告必须基于本轮新生成的 `report_text`、`report_text_path` 内部正文或本轮新生成的报告文件，以及本轮新生成的 `inquiries.json`；禁止使用旧报告、旧 JSON、模型记忆或任务标题补写结果。
3. 最终回复正文必须包含完整 1-6 模块：总览统计、商机类型、负责人跟进看板、待跟进重点、全量询盘明细、数据完整性说明。
4. 禁止工作摘要替代完整报告；不能只输出“工作摘要 / 数据抓取 / 分析报告 / 重点提醒 / 报告路径”后结束。
5. 如果报告顶部包含“当前中国时间尚未到达本次统计窗口结束时间”的提示，最终回复必须原样保留该提示。
6. 如果报告中包含“实际抓取窗口”或 `统计日期` / `统计时段`，最终回复必须保留该窗口，不得改写成另一个时区口径。
7. 日期字符串窗口不得被说成“美西今日”或“美西 YYYY-MM-DD”，除非报告明确标注它完整匹配美西当天 `[00:00, 次日 00:00)`。
8. timestamp 窗口也必须以报告里展示的实际抓取窗口为准；不得因为任务标题、自然语言请求或上一轮结果自行改写时间口径。
9. 只有本轮启用 Markdown 或 PDF 导出时，最终回复末尾才出现 `## 报告文件` 区块；导出关闭时不得出现 Markdown/PDF 文件链接、路径或未生成提示。

## 公开入口

对外只保留 manager 抓取主线。自然语言里的时间表达必须先由 skill 按目标时区解析为显式时间窗，再调用同一个 manager 入口：

第一次工具调用：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time <开始毫秒时间戳> --end-time <结束毫秒时间戳>
```

默认后续工具调用：

```powershell
python -X utf8 scripts\accio_scrape_manager.py wait
```

若 `wait` 返回 `running`，继续运行：

```powershell
python -X utf8 scripts\accio_scrape_manager.py wait
```

可选过滤：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time <开始毫秒时间戳> --end-time <结束毫秒时间戳> --category TM
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time <开始毫秒时间戳> --end-time <结束毫秒时间戳> --assignee "Lily Tan"
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time <开始毫秒时间戳> --end-time <结束毫秒时间戳> --buyer-name "Loretta Paulus"
```

## 时间窗规则

- 用户明确说“中国”“中国时间”“北京时间”“中国时区”“UTC+8”“国内时间”等等价表达时，必须按 `Asia/Shanghai` 解释，并使用中国时间自然日/自然范围计算时间戳；此规则优先级高于默认美西规则。
- 例如“北京时间今日/今天”在 2026-05-06 发起时，目标窗口必须是北京时间 `2026-05-06 00:00:00` 至 `2026-05-07 00:00:00`，不能使用对应美西自然日的北京时间 `15:00` 至次日 `15:00`。
- 用户只说时间范围、日期或相对日期，而没有明确指定时区/地区时，统一按美西 `America/Los_Angeles` 解释。
- 适用范围包括但不限于：“今天/今日”“昨天/昨日”“前天”“本周/上周”“本月/上月”“近 7 天”“4 月 28 日”“昨天上午”等。
- 禁止因为用户重复询问同一日期、界面语言是中文、运行环境或系统时区是 `Asia/Shanghai`、上一轮报告口径、或美西结果与上一轮结果相同而自行切换到北京时间；这些都不是显式时区指定。
- 不使用运行机器、会话环境、浏览器或本地系统时区作为默认时间口径。
- 所有自然语言时间必须先按目标时区换算成明确的 `[start, end)` 时间窗，再传 13 位毫秒时间戳到 `--start-time` / `--end-time`。
- 启动 `start` 前必须自检：用户原话含“北京时间/中国时间”等中国时区表达时，计算时间戳的命令和工具调用描述不得出现 `America/Los_Angeles` / “美西”；若出现，必须重新按 `Asia/Shanghai` 计算。
- 计算毫秒时间戳时使用请求发生时的真实日期；美西时间必须用 `America/Los_Angeles`，不能手写固定 UTC-8，以自动处理 PDT/PST 夏令时。
- 用户直接提供显式历史范围时，只接受 `--start-time` / `--end-time`，可传 `YYYY-MM-DD`、带时分秒的时间、10 位秒时间戳或 13 位毫秒时间戳。
- `--end-time` 是排他边界；例如查询 2026-04-23 到 2026-04-25，应传：

```powershell
python -X utf8 scripts\accio_scrape_manager.py start --mode new --start-time 2026-04-23 --end-time 2026-04-26
```

- 不新增或推荐 `--timezone` 参数；时区解释属于 skill 规范，脚本只接收明确时间窗参数。
- 不把“今日/今天/昨日/中国时间”等自然语言提示词识别写进 Python 脚本。
- 旧模式名和旧日期简写参数已移除，不能再推荐、回显或执行。
- 买家名搜索在未显式给时间窗时，使用后台默认最近一年范围。

## 时间戳计算

美西今日：

```powershell
python -X utf8 -c "from datetime import datetime,timedelta; from zoneinfo import ZoneInfo; tz=ZoneInfo('America/Los_Angeles'); s=datetime.now(tz).replace(hour=0,minute=0,second=0,microsecond=0); e=s+timedelta(days=1); print(int(s.timestamp()*1000), int(e.timestamp()*1000))"
```

美西昨日：

```powershell
python -X utf8 -c "from datetime import datetime,timedelta; from zoneinfo import ZoneInfo; tz=ZoneInfo('America/Los_Angeles'); e=datetime.now(tz).replace(hour=0,minute=0,second=0,microsecond=0); s=e-timedelta(days=1); print(int(s.timestamp()*1000), int(e.timestamp()*1000))"
```

中国时间今日：

```powershell
python -X utf8 -c "from datetime import datetime,timedelta; from zoneinfo import ZoneInfo; tz=ZoneInfo('Asia/Shanghai'); s=datetime.now(tz).replace(hour=0,minute=0,second=0,microsecond=0); e=s+timedelta(days=1); print(int(s.timestamp()*1000), int(e.timestamp()*1000))"
```

中国时间昨日：

```powershell
python -X utf8 -c "from datetime import datetime,timedelta; from zoneinfo import ZoneInfo; tz=ZoneInfo('Asia/Shanghai'); e=datetime.now(tz).replace(hour=0,minute=0,second=0,microsecond=0); s=e-timedelta(days=1); print(int(s.timestamp()*1000), int(e.timestamp()*1000))"
```

## 标准流程

### 今日/昨日前一日对比

- 今日/昨日完整日窗口由 `scripts\accio_scrape_manager.py` 自动识别并补抓主窗口前一日，报告会自动加入商机数量和用户等级占比对比；不要手动编排第二轮抓取或覆盖主窗口明细。

1. 先判断是自然语言时间主线、显式历史时间窗，还是买家名搜索。
2. 时间主线先按目标时区计算 13 位毫秒时间戳，再运行与目标窗口匹配的 `accio_scrape_manager.py start` 命令。
3. 任务标题、任务描述、`start` 命令时间戳、报告时间口径必须与第 2 步的时区判定一致；例如用户只说“查询 28 号”时，不得在标题或报告中写成 `Beijing Time`，除非用户原话明确指定北京时间/中国时间。
4. `start` 必须单独运行，不要把 `start && status`、`start && finish`、`start && watch` 或多行 start/status/finish/watch 放进同一次 Bash 工具调用。
5. start 成功后默认只运行 `accio_scrape_manager.py wait`；若返回 `status=running` 则继续运行 `wait`，不要切回高频 `status` 轮询。
6. `wait=running` 时只看默认返回的约 1 行 `log_tail` 和精简 progress；不要额外读日志、列目录、查进程或重复确认。只有返回 `error_log_tail` / 错误字段，或用户明确要求排查时才读日志。
7. `wait=completed` 后直接输出报告，不要再运行 `finish`；`finish` 只用于兼容/人工修复。
8. 默认不要运行 `watch --force --max-minutes auto`，也不要用 `sleep`/`timeout` 串联等待。长超时 runner 若运行 watch，必须通过工具超时环境变量证明超时上限大于 watch 预计等待时间；否则即使带 `--force` 也会返回 blocked，并提示改用 wait。
9. `watch --force --max-minutes auto` 是终结命令；当 watch 返回 `status=completed` 且包含 `report_path` 或 `report.output` 时，表示已经完成校验、报告生成和 tab 清理，后续禁止再运行 `finish` 或 `scripts\accio_generate_report.py`。
10. 选择 watch 路线时，不要创建或执行 “Finalize scraping session” / `finish` 任务；如果该任务已经创建，watch completed 后应标记为无需执行，并直接读取 watch 返回的 `report_path` 展示报告。
11. 如果 Bash 工具或 watch 超时，或 watch 返回 blocked，不能读取旧 `inquiries.json` 出报告；应继续低频运行 `status`，完成后运行 `finish`，仍不要重新 start。
12. 抓取成功后再读取项目根目录的 `inquiries.json`，并确认文件是本轮抓取生成，不使用旧文件。
13. 校验 `status == "ok"`，并确认窗口、过滤条件、任务标题/描述和用户请求一致。
14. 如需报告或结果反馈，按 `references/reporting.md` 生成结构化底稿，并输出 Accio Work 风格完整报告，不输出简约版本。
15. 最终回复必须基于 manager 和报告脚本的实际产物；若任一命令没有运行成功，则不能输出报告。
16. 输出最终回复前核对 manager JSON 或 state：导出关闭时使用 `report_text`；如果返回 `report_text_omitted=true` 或没有完整 `report_text`，必须先读取 `report_text_path`，不得凭统计摘要、记忆或任务标题补写第 5 模块；不得添加文件区块。启用 Markdown 时才把 `report_path` 带入 `## 报告文件` 区块；启用并成功生成 PDF 时才带入 `pdf_report_path`。
17. 下游 skill/自动化消费 manager JSON 时同样遵守第 16 条：优先用完整 `report_text`；正文省略时读取 `report_text_path`；读取失败就重新生成，不输出内部路径。

## 参考文档

- 默认列表与高级搜索入口：`references/page_selectors.md`
- 历史时间窗与批处理：`references/advance_time.md`
- 买家名称搜索：`references/buyer_name_search.md`
- 输出字段与报告口径：`references/reporting.md`
- 负责人缓存：`references/assignee_workflows.md`
- 登录态清理：`references/login_state.md`

## 重要约束

- 如果抓取过程中消息中心跳转到 `https://login.alibaba.com/`，必须立即视为 `login_required` 硬中断：停止当前抓取、不要重试、不要读取旧 `inquiries.json`、不要生成报告，并提示用户在新打开的浏览器里完成阿里国际站登录后重新运行查询。
- 只读抓取，不发送消息、不提交表单。
- 默认结果始终写回项目根目录 `inquiries.json`。
- 不在对外说明中使用“按创建时间排序”或“按更新时间排序”作为系统能力定义。
