# B2B 客户深度背调 (B2B Deep Customer Research)

## 技能描述
专门用于 B2B 销售和市场开发场景的深度客户调查。通过整合官网分析、社交媒体挖掘、贸易数据检索和邮箱校验，为销售人员提供“带温度”的客户情报，大幅提升开发信回复率。

## 适用场景
- **精准获客**: 需要从零开始了解一个潜在客户。
- **高价值客户攻坚**: 针对 Top 级客户进行全方位情报搜集。
- **个性化开发信**: 寻找除了“我是厂家”之外的沟通切入点。

## 工作流步骤

### 1. 公司官网多维扫描 (Site Analysis)
- **核心业务**: 提取 Mission Statement 和核心产品线。
- **目标行业**: 识别他们服务的垂直行业（如：物流、医疗、国防）。
- **合作伙伴/代理品牌**: 识别他们目前代理的竞品或互补品牌。
- **关键页面**: 必看 About Us, News, Blog, Case Studies, Partners。

### 2. 关键决策人 (DM) 挖掘
- **目标角色**: CEO, Founder, Director of Purchasing, Product Manager, Business Development Manager。
- **挖掘路径**: 
  - `site:linkedin.com/in/ "Company Name" (Role keywords)`
  - 官网 "Management Team" 页面。
  - 行业展会名单、新闻稿中的引言人。

### 3. 联系方式提取与校验 (Contact Discovery)
- **邮箱获取**: 结合 `browser` 或 `web_search` 寻找模式（如 first.last@domain.com）。
- **真实性校验**: 调用 `verify_email.py` 脚本确保邮箱不退信。

### 4. 业务“钩子”挖掘 (Business Hook Discovery)
- **贸易情报**: 检索 HS Code 相关的进出口记录（基于相关 CRM 或公开海关数据）。
- **技术栈/需求点**: 从 Job Postings 或 Case Studies 中分析他们目前面临的技术痛点。
- **最新大事件**: 
  - 过去 6 个月内的并购、获奖、新产品发布。
  - 行业动态与该公司的关联。

### 5. 生成背调报告 (Report Synthesis)
按以下模板输出：

---
# [Company Name] 深度背调报告

### 🏢 企业基本信息
- **规模/性质**: [例如: 100-200人, 增值分销商]
- **核心竞争力**: [简述]
- **目前分销品牌**: [品牌A, 品牌B]

### 👥 核心决策人
| 姓名 | 职位 | 邮箱 (Verified) | LinkedIn |
| :--- | :--- | :--- | :--- |
| [Name] | [Role] | [Email] | [Link] |

### 🔍 深度情报 (Personalization Hooks)
- **海关数据**: [如: 202X年X月进口了XXXX台 [产品], 供应商为 X]
- **近期动态**: [如: 刚在[展会]上发布了 [新方案]]
- **痛点分析**: [如: 官网案例显示其在[特定场景]下的[性能/稳定性]有待提升]

### 💡 推荐开发信切入点
> "注意到贵司近期在 [项目/动态] 方面的进展，考虑到我们 [品牌/产品] 的 [产品特点] 正好能解决 [痛点]..."
---

## 常用查询指令
- `site:linkedin.com/company "[Company]"`
- `"[Company]" "[Relevant HS Code]" import shipments`
- `"[Company]" case study [Product/Keywords]`
- `"[Company]" "[Decision Maker Name]" email`

## 注意事项
- 严禁伪造邮箱，所有联系方式必须经过校验。
- 区分公共邮箱 (info@) 和个人邮箱 (name@)，优先使用个人邮箱。
- 建议建立客户库文件（如 `contacted-companies.json`）以追踪动态，避免重复工作。
