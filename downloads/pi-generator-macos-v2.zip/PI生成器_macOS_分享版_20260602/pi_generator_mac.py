#!/usr/bin/env python3
import datetime as dt
import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
import tkinter as tk

from PIL import Image, ImageTk
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image as PdfImage,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter


APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "pi_generator_config.json"
EXPORT_DIR = APP_DIR / "exports"
DRAFT_DIR = APP_DIR / "drafts"

UI_BG = "#f5f5f7"
CARD_BG = "#ffffff"
TEXT = "#1d1d1f"
MUTED = "#6e6e73"
BORDER = "#d2d2d7"
SOFT_BORDER = "#e5e5ea"
PRIMARY = "#0071e3"
SUCCESS = "#248a3d"
DANGER = "#d70015"
WARNING = "#f5a524"


def money(value):
    return Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def today():
    return dt.date.today().isoformat()


def add_days(days):
    try:
        value = int(days or 15)
    except (TypeError, ValueError):
        value = 15
    return (dt.date.today() + dt.timedelta(days=value)).isoformat()


def default_doc_no(doc_type="quotation"):
    prefix = "QT" if doc_type == "quotation" else "PI"
    return f"{prefix}-{dt.datetime.now().strftime('%Y%m%d-%H%M')}"


@dataclass
class Item:
    picture_label: str = ""
    name_en: str = ""
    name_cn: str = ""
    spec: str = ""
    material: str = ""
    usage: str = ""
    cbm: float = 0
    quantity: float = 0
    unit: str = "pcs"
    unit_price: float = 0
    image_path: str = ""

    @property
    def subtotal(self):
        return money(Decimal(str(self.quantity or 0)) * Decimal(str(self.unit_price or 0)))


DEFAULT_CONFIG = {
    "company_cn": "",
    "company_en": "",
    "address_cn": "",
    "address_en": "",
    "phone": "",
    "email": "",
    "website": "",
    "show_phone": False,
    "exchange_rate": "7.20",
    "deepseek_api_key": "",
    "deepseek_api_url": "https://api.deepseek.com/chat/completions",
    "deepseek_model": "deepseek-chat",
    "payment_terms": "100% advance payment / 100%预付款",
    "trade_terms": "EXW Yiwu / 义乌工厂交货",
    "delivery_time": "15-30 days after deposit. / 收到定金后15-30天。",
    "validity_days": "15",
    "logo_path": "",
    "signature_path": "",
}


class PiGeneratorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("形式发票生成器 - Quotation / Proforma Invoice Generator for macOS")
        self.geometry("1420x850")
        self.minsize(1120, 720)
        self.configure(bg=UI_BG)
        self.config_data = self.load_config()
        self.items = []
        self.selected_index = None
        self.image_cards = []
        self.tk_images = []
        self.document_no_var = tk.StringVar(value=default_doc_no())
        self.buyer_vars = {}
        self.asset_vars = {}
        self.terms_vars = {}
        self.remarks_text = None
        self._build_styles()
        self._build_ui()
        self._load_settings_into_ui()
        self._refresh_items()

    def load_config(self):
        if CONFIG_PATH.exists():
            try:
                data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                merged = DEFAULT_CONFIG.copy()
                merged.update(data)
                return merged
            except Exception:
                pass
        return DEFAULT_CONFIG.copy()

    def save_config(self):
        CONFIG_PATH.write_text(json.dumps(self.config_data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _build_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", rowheight=34, background=CARD_BG, fieldbackground=CARD_BG,
                        foreground=TEXT, bordercolor=SOFT_BORDER, relief="flat")
        style.configure("Treeview.Heading", background="#f2f2f7", foreground=TEXT, font=("Arial", 11, "bold"),
                        bordercolor=SOFT_BORDER, relief="flat")
        style.map("Treeview", background=[("selected", "#e8f2ff")], foreground=[("selected", TEXT)])
        style.configure("TNotebook", background=UI_BG, borderwidth=0)
        style.configure("TNotebook.Tab", background="#eeeeef", foreground=MUTED, padding=(16, 9),
                        font=("Arial", 11, "bold"))
        style.map("TNotebook.Tab", background=[("selected", CARD_BG)], foreground=[("selected", TEXT)])

    def _button(self, parent, text, command, bg="#f2f2f7", width=None, fg=TEXT):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg, activebackground=bg,
                         activeforeground=fg, relief="flat", bd=0, padx=10, pady=6,
                         font=("Arial", 10, "bold"), width=width, cursor="pointinghand")

    def _entry(self, parent, textvar=None, show=None):
        return tk.Entry(parent, textvariable=textvar, show=show, bg="#fbfbfd", fg=TEXT,
                        insertbackground=TEXT, relief="solid", bd=1, highlightthickness=1,
                        highlightbackground=SOFT_BORDER, highlightcolor=PRIMARY, font=("Arial", 11))

    def _label(self, parent, text, bold=False, fg=MUTED):
        return tk.Label(parent, text=text, bg=parent.cget("bg"), fg=fg, anchor="w",
                        font=("Arial", 11, "bold" if bold else "normal"))

    def _frame(self, parent):
        return tk.Frame(parent, bg=CARD_BG, highlightthickness=1, highlightbackground=SOFT_BORDER)

    def _build_ui(self):
        toolbar = tk.Frame(self, bg=CARD_BG, highlightthickness=1, highlightbackground=SOFT_BORDER)
        toolbar.pack(fill="x", padx=0, pady=0)
        self._button(toolbar, "新建", self.new_document, "#f2f2f7", fg=TEXT).pack(side="left", padx=6, pady=8)
        self._button(toolbar, "AI整理", self.ai_fill, PRIMARY, fg=TEXT).pack(side="left", padx=4, pady=8)
        self._button(toolbar, "保存设置", self.save_settings, "#f2f2f7", fg=TEXT).pack(side="left", padx=4, pady=8)
        self._button(toolbar, "Logo", lambda: self.choose_asset("logo_path"), "#f2f2f7", fg=TEXT).pack(side="left", padx=4, pady=8)
        self._button(toolbar, "签名/盖章", lambda: self.choose_asset("signature_path"), "#f2f2f7", fg=TEXT).pack(side="left", padx=4, pady=8)
        self._button(toolbar, "保存草稿", self.save_draft, "#f2f2f7", fg=TEXT).pack(side="left", padx=4, pady=8)
        self._button(toolbar, "载入草稿", self.load_draft, "#f2f2f7", fg=TEXT).pack(side="left", padx=4, pady=8)
        self._button(toolbar, "导出Excel", self.export_excel, SUCCESS, fg=TEXT).pack(side="left", padx=6, pady=8)

        main = tk.PanedWindow(self, orient="horizontal", bg=UI_BG, sashwidth=4, bd=0)
        main.pack(fill="both", expand=True)
        left = tk.Frame(main, bg=UI_BG)
        center = tk.Frame(main, bg=UI_BG)
        right = tk.Frame(main, bg=UI_BG)
        main.add(left, minsize=300, width=390)
        main.add(center, minsize=520, width=620)
        main.add(right, minsize=330, width=390)

        self._build_left(left)
        self._build_center(center)
        self._build_right(right)

    def _build_left(self, parent):
        scroll_canvas = tk.Canvas(parent, bg=UI_BG, highlightthickness=0)
        scroll_canvas.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=scroll_canvas.yview)
        scrollbar.pack(side="right", fill="y")
        scroll_canvas.configure(yscrollcommand=scrollbar.set)
        content = tk.Frame(scroll_canvas, bg=UI_BG)
        canvas_window = scroll_canvas.create_window((0, 0), window=content, anchor="nw")
        content.bind("<Configure>", lambda _e: scroll_canvas.configure(scrollregion=scroll_canvas.bbox("all")))
        scroll_canvas.bind("<Configure>", lambda e: scroll_canvas.itemconfigure(canvas_window, width=e.width))

        box = self._frame(content)
        box.pack(fill="both", expand=False, padx=12, pady=12)
        self._label(box, "需求上传 / Request Intake", True, TEXT).pack(fill="x", padx=14, pady=(12, 2))
        self._label(box, "粘贴客户消息、Excel复制内容或产品清单，一键整理成 PI 商品行。", False, MUTED).pack(fill="x", padx=14, pady=(0, 8))
        brand_actions = tk.Frame(box, bg=CARD_BG)
        brand_actions.pack(fill="x", padx=14, pady=(0, 8))
        brand_actions.columnconfigure(1, weight=1)
        brand_actions.columnconfigure(2, weight=1)
        self._label(brand_actions, "单据品牌").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self._button(brand_actions, "Logo", lambda: self.choose_asset("logo_path"), "#f2f2f7", fg=TEXT).grid(row=0, column=1, sticky="ew", padx=(0, 4))
        self._button(brand_actions, "签名/盖章", lambda: self.choose_asset("signature_path"), "#f2f2f7", fg=TEXT).grid(row=0, column=2, sticky="ew", padx=(4, 0))
        self.raw_text = tk.Text(box, height=7, bg="#fbfbfd", fg=TEXT, insertbackground=TEXT,
                                relief="solid", bd=1, highlightthickness=1, highlightbackground=SOFT_BORDER,
                                highlightcolor=PRIMARY, font=("Arial", 11), wrap="word")
        self.raw_text.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        intake_actions = tk.Frame(box, bg=CARD_BG)
        intake_actions.pack(fill="x", padx=14, pady=(0, 8))
        for col in range(4):
            intake_actions.columnconfigure(col, weight=1)
        self._button(intake_actions, "粘贴", self.paste_request_text, "#f2f2f7", fg=TEXT).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self._button(intake_actions, "导入", self.load_request_text, "#f2f2f7", fg=TEXT).grid(row=0, column=1, sticky="ew", padx=4)
        self._button(intake_actions, "示例", self.insert_sample_request, "#f2f2f7", fg=TEXT).grid(row=0, column=2, sticky="ew", padx=4)
        self._button(intake_actions, "清空", self.clear_request_text, "#f2f2f7", fg=TEXT).grid(row=0, column=3, sticky="ew", padx=(4, 0))
        key_row = tk.Frame(box, bg=CARD_BG)
        key_row.pack(fill="x", padx=14, pady=(0, 8))
        self.api_key_var = tk.StringVar()
        key_row.columnconfigure(0, weight=1)
        self._entry(key_row, self.api_key_var, show="•").grid(row=0, column=0, sticky="ew")
        self._button(key_row, "保存Key", self.save_settings, "#f2f2f7", fg=TEXT).grid(row=0, column=1, padx=(8, 0))
        gen_row = tk.Frame(box, bg=CARD_BG)
        gen_row.pack(fill="x", padx=14, pady=(0, 8))
        self.doc_type = tk.StringVar(value="quotation")
        self.doc_type.trace_add("write", lambda *_: self.update_default_doc_no())
        tk.Radiobutton(gen_row, text="报价单", variable=self.doc_type, value="quotation", bg="#f2f2f7",
                       fg=TEXT, selectcolor="#dbeafe", indicatoron=False, width=12,
                       font=("Arial", 12, "bold")).pack(side="left", fill="x", expand=True, padx=(0, 4))
        tk.Radiobutton(gen_row, text="形式发票", variable=self.doc_type, value="proforma_invoice", bg="#f2f2f7",
                       fg=TEXT, selectcolor="#dbeafe", indicatoron=False, width=12,
                       font=("Arial", 12, "bold")).pack(side="left", fill="x", expand=True, padx=(4, 0))
        doc_row = tk.Frame(box, bg=CARD_BG)
        doc_row.pack(fill="x", padx=14, pady=(0, 8))
        self._label(doc_row, "单据号").pack(side="left", padx=(0, 8))
        self._entry(doc_row, self.document_no_var).pack(side="left", fill="x", expand=True)
        self._button(box, "整理并生成商品行 / Organize Items", self.ai_fill, PRIMARY, fg=TEXT).pack(fill="x", padx=14, pady=(0, 14))

        rate = self._frame(content)
        rate.pack(fill="x", padx=12, pady=(0, 12))
        self._label(rate, "美元汇率 / USD Rate", True, TEXT).pack(fill="x", padx=14, pady=(10, 4))
        row = tk.Frame(rate, bg=CARD_BG)
        row.pack(fill="x", padx=14, pady=10)
        row.columnconfigure(1, weight=1)
        self._label(row, "1 USD =").grid(row=0, column=0, sticky="w", padx=(0, 6))
        self.rate_var = tk.StringVar()
        self._entry(row, self.rate_var).grid(row=0, column=1, sticky="ew", padx=(0, 6))
        self._label(row, "RMB").grid(row=0, column=2, sticky="w", padx=(0, 6))
        self._button(row, "转换", self.convert_rmb_to_usd, "#f2f2f7", fg=TEXT).grid(row=0, column=3, sticky="e")

        seller = self._frame(content)
        seller.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self._label(seller, "卖方设置 / Seller", True, TEXT).pack(fill="x", padx=14, pady=(10, 4))
        self.seller_vars = {}
        fields = [("公司中文 / CN", "company_cn"), ("Company EN", "company_en"), ("地址中文 / CN Addr", "address_cn"),
                  ("Address EN", "address_en"), ("电话 / Phone", "phone"), ("邮箱 / Email", "email"),
                  ("网站 / Website", "website")]
        for label, key in fields:
            row = tk.Frame(seller, bg=CARD_BG)
            row.pack(fill="x", padx=14, pady=4)
            row.columnconfigure(1, weight=1)
            self._label(row, label).grid(row=0, column=0, sticky="w", padx=(0, 8))
            var = tk.StringVar()
            self.seller_vars[key] = var
            self._entry(row, var).grid(row=0, column=1, sticky="ew")
        self.show_phone_var = tk.BooleanVar()
        tk.Checkbutton(seller, text="显示电话到单据 / Show phone on document", variable=self.show_phone_var,
                       bg=CARD_BG, fg=TEXT, selectcolor=CARD_BG,
                       activebackground=CARD_BG, activeforeground=TEXT).pack(anchor="w", padx=14, pady=8)

        buyer = self._frame(content)
        buyer.pack(fill="x", padx=12, pady=(0, 12))
        self._label(buyer, "买方资料 / Buyer", True, TEXT).pack(fill="x", padx=14, pady=(10, 4))
        buyer_fields = [("客户名 / Name", "buyer_name"), ("联系人 / Contact", "buyer_contact"),
                        ("地址 / Address", "buyer_address"), ("邮箱 / Email", "buyer_email"),
                        ("电话 / Phone", "buyer_phone")]
        for label, key in buyer_fields:
            row = tk.Frame(buyer, bg=CARD_BG)
            row.pack(fill="x", padx=14, pady=3)
            row.columnconfigure(1, weight=1)
            self._label(row, label).grid(row=0, column=0, sticky="w", padx=(0, 8))
            var = tk.StringVar()
            self.buyer_vars[key] = var
            self._entry(row, var).grid(row=0, column=1, sticky="ew")

        terms = self._frame(content)
        terms.pack(fill="x", padx=12, pady=(0, 12))
        self._label(terms, "条款/备注 / Terms", True, TEXT).pack(fill="x", padx=14, pady=(10, 4))
        term_fields = [
            ("付款方式", "payment_terms"),
            ("贸易条款", "trade_terms"),
            ("交期", "delivery_time"),
            ("有效期天数", "validity_days"),
        ]
        for label, key in term_fields:
            row = tk.Frame(terms, bg=CARD_BG)
            row.pack(fill="x", padx=14, pady=3)
            row.columnconfigure(1, weight=1)
            self._label(row, label).grid(row=0, column=0, sticky="w", padx=(0, 8))
            var = tk.StringVar()
            self.terms_vars[key] = var
            self._entry(row, var).grid(row=0, column=1, sticky="ew")
        self._label(terms, "备注 / Remarks").pack(fill="x", padx=14, pady=(6, 2))
        self.remarks_text = tk.Text(terms, height=4, bg="#fbfbfd", fg=TEXT, insertbackground=TEXT,
                                    relief="solid", bd=1, highlightthickness=1,
                                    highlightbackground=SOFT_BORDER, highlightcolor=PRIMARY,
                                    font=("Arial", 11), wrap="word")
        self.remarks_text.pack(fill="x", padx=14, pady=(0, 10))

        assets = self._frame(content)
        assets.pack(fill="x", padx=12, pady=(0, 12))
        self._label(assets, "Logo/签名 / Branding", True, TEXT).pack(fill="x", padx=14, pady=(10, 4))
        for label, key in [("Logo", "logo_path"), ("签名/盖章", "signature_path")]:
            row = tk.Frame(assets, bg=CARD_BG)
            row.pack(fill="x", padx=14, pady=4)
            row.columnconfigure(1, weight=1)
            self._label(row, label).grid(row=0, column=0, sticky="w", padx=(0, 8))
            var = self.asset_vars.get(key) or tk.StringVar()
            self.asset_vars[key] = var
            self._entry(row, var).grid(row=0, column=1, sticky="ew")
            self._button(row, "选择", lambda k=key: self.choose_asset(k), "#f2f2f7", fg=TEXT).grid(row=0, column=2, padx=(8, 0))

    def _build_center(self, parent):
        top = tk.Frame(parent, bg=UI_BG)
        top.pack(fill="x", padx=12, pady=(12, 4))
        self._label(top, "商品明细 / Product Items", True, TEXT).pack(side="left")
        self.total_var = tk.StringVar(value="Total / 总计: USD 0.00")
        tk.Label(top, textvariable=self.total_var, bg=UI_BG, fg=TEXT,
                 font=("Arial", 16, "bold")).pack(side="right")
        cols = ("pic", "name_en", "name_cn", "spec", "material", "usage", "cbm", "qty", "unit", "price", "amount")
        self.tree = ttk.Treeview(parent, columns=cols, show="headings", height=15)
        headings = ["图片", "英文品名", "中文品名", "规格", "材料", "用途", "CBM", "数量", "单位", "单价", "小计"]
        widths = [58, 105, 94, 76, 74, 74, 58, 58, 48, 68, 82]
        for col, head, width in zip(cols, headings, widths):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=width, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        self.tree.bind("<<TreeviewSelect>>", self.on_select_item)
        self.tree.bind("<Double-1>", self.edit_selected_item)

        edit = self._frame(parent)
        edit.pack(fill="x", padx=12, pady=8)
        self.edit_vars = {k: tk.StringVar() for k in [
            "name_en", "name_cn", "spec", "material", "usage", "cbm",
            "quantity", "unit", "unit_price"
        ]}
        grid = tk.Frame(edit, bg=CARD_BG)
        grid.pack(fill="x", padx=12, pady=10)
        labels = [
            ("英文品名", "name_en"), ("中文品名", "name_cn"), ("规格", "spec"),
            ("材料", "material"), ("用途", "usage"), ("CBM", "cbm"),
            ("数量", "quantity"), ("单位", "unit"), ("单价", "unit_price")
        ]
        for i, (label, key) in enumerate(labels):
            row_base = 0 if i < 5 else 2
            col = i if i < 5 else i - 5
            self._label(grid, label).grid(row=row_base, column=col, sticky="w", padx=4)
            self._entry(grid, self.edit_vars[key]).grid(row=row_base + 1, column=col, sticky="ew", padx=4, pady=(3, 8))
            grid.columnconfigure(col, weight=1)
        btns = tk.Frame(edit, bg=CARD_BG)
        btns.pack(fill="x", padx=12, pady=(0, 10))
        self._button(btns, "添加 / Add", self.add_item, "#f2f2f7", fg=TEXT).pack(side="left", fill="x", expand=True, padx=(0, 4))
        self._button(btns, "更新 / Update", self.update_item, PRIMARY, fg=TEXT).pack(side="left", fill="x", expand=True, padx=4)
        self._button(btns, "删除 / Delete", self.delete_item, "#f2f2f7", fg=DANGER).pack(side="left", fill="x", expand=True, padx=4)
        self._button(btns, "生成PDF", self.generate_pdf, PRIMARY, fg=TEXT).pack(side="left", fill="x", expand=True, padx=(4, 0))

    def _build_right(self, parent):
        tabs = ttk.Notebook(parent)
        tabs.pack(fill="both", expand=True, padx=12, pady=12)
        img_tab = tk.Frame(tabs, bg=CARD_BG)
        preview_tab = tk.Frame(tabs, bg=CARD_BG)
        tabs.add(img_tab, text="商品图片 / Images")
        tabs.add(preview_tab, text="单据预览 / Preview")
        self._label(img_tab, "商品图片 / Product Images", True, TEXT).pack(fill="x", padx=12, pady=(12, 4))
        self._label(img_tab, "选择商品行后添加图片，也可以批量按顺序导入。", False, MUTED).pack(fill="x", padx=12, pady=(0, 8))
        grid = tk.Frame(img_tab, bg=CARD_BG)
        grid.pack(fill="both", expand=True, padx=12)
        for i in range(6):
            card = tk.Frame(grid, bg="#fbfbfd", highlightthickness=1, highlightbackground=SOFT_BORDER, width=180, height=120)
            card.grid(row=i // 2, column=i % 2, padx=8, pady=8, sticky="nsew")
            card.grid_propagate(False)
            label = tk.Label(card, text=f"商品{i+1}\n点击选择图片", bg="#fbfbfd", fg=MUTED, font=("Arial", 11))
            label.pack(fill="both", expand=True)
            card.bind("<Button-1>", lambda _e, idx=i: self.choose_image(idx))
            label.bind("<Button-1>", lambda _e, idx=i: self.choose_image(idx))
            self.image_cards.append(label)
        for i in range(2):
            grid.columnconfigure(i, weight=1)
        for i in range(3):
            grid.rowconfigure(i, weight=1)
        img_btns = tk.Frame(img_tab, bg=CARD_BG)
        img_btns.pack(fill="x", padx=12, pady=10)
        self._button(img_btns, "选图", self.choose_selected_image, PRIMARY, fg=TEXT).pack(side="left", fill="x", expand=True, padx=(0, 4))
        self._button(img_btns, "批量导入", self.bulk_add_images, "#f2f2f7", fg=TEXT).pack(side="left", fill="x", expand=True, padx=4)
        self._button(img_btns, "清空", self.clear_selected_image, "#f2f2f7", fg=TEXT).pack(side="left", fill="x", expand=True, padx=(4, 0))

        self.preview_text = tk.Text(preview_tab, bg="#fbfbfd", fg=TEXT, relief="solid", bd=1,
                                    highlightthickness=1, highlightbackground=SOFT_BORDER,
                                    wrap="word", font=("Arial", 11))
        self.preview_text.pack(fill="both", expand=True, padx=12, pady=12)

    def _load_settings_into_ui(self):
        self.api_key_var.set(self.config_data.get("deepseek_api_key", ""))
        self.rate_var.set(self.config_data.get("exchange_rate", "7.20"))
        self.show_phone_var.set(bool(self.config_data.get("show_phone", False)))
        for key, var in self.seller_vars.items():
            var.set(self.config_data.get(key, ""))
        for key, var in self.asset_vars.items():
            var.set(self.config_data.get(key, ""))
        self.reset_terms_from_defaults(clear_remarks=True)

    def collect_settings(self):
        self.config_data["deepseek_api_key"] = self.api_key_var.get().strip()
        self.config_data["exchange_rate"] = self.rate_var.get().strip() or "7.20"
        self.config_data["show_phone"] = self.show_phone_var.get()
        for key, var in self.seller_vars.items():
            self.config_data[key] = var.get().strip()
        for key, var in self.asset_vars.items():
            self.config_data[key] = var.get().strip()

    def save_settings(self):
        self.collect_settings()
        self.save_config()
        messagebox.showinfo("保存成功", f"设置已保存到：\n{CONFIG_PATH}")

    def new_document(self):
        if self.items and not messagebox.askyesno("新建", "清空当前商品并新建单据？"):
            return
        self.items = []
        self.selected_index = None
        self.document_no_var.set(default_doc_no(self.doc_type.get()))
        for var in self.buyer_vars.values():
            var.set("")
        self.reset_terms_from_defaults(clear_remarks=True)
        self.raw_text.delete("1.0", "end")
        self._refresh_items()

    def reset_terms_from_defaults(self, clear_remarks=False):
        for key, var in self.terms_vars.items():
            var.set(str(self.config_data.get(key, DEFAULT_CONFIG.get(key, ""))))
        if clear_remarks and self.remarks_text is not None:
            self.remarks_text.delete("1.0", "end")

    def get_terms_state(self):
        return {
            "payment_terms": self.terms_vars.get("payment_terms", tk.StringVar()).get().strip(),
            "trade_terms": self.terms_vars.get("trade_terms", tk.StringVar()).get().strip(),
            "delivery_time": self.terms_vars.get("delivery_time", tk.StringVar()).get().strip(),
            "validity_days": self.terms_vars.get("validity_days", tk.StringVar()).get().strip() or "15",
            "remarks": self.remarks_text.get("1.0", "end").strip() if self.remarks_text is not None else "",
        }

    def apply_terms_state(self, terms):
        terms = terms or {}
        for key, var in self.terms_vars.items():
            var.set(str(terms.get(key, self.config_data.get(key, DEFAULT_CONFIG.get(key, "")))))
        if self.remarks_text is not None:
            self.remarks_text.delete("1.0", "end")
            self.remarks_text.insert("1.0", terms.get("remarks", ""))

    def update_default_doc_no(self):
        current = self.document_no_var.get().strip()
        if not current or re.match(r"^(QT|PI)-\d{8}-\d{4}$", current):
            self.document_no_var.set(default_doc_no(self.doc_type.get()))

    def choose_asset(self, key):
        path = filedialog.askopenfilename(
            title="选择图片",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")]
        )
        if path:
            self.asset_vars[key].set(path)
            self.collect_settings()
            self.save_config()
            self._refresh_preview()

    def paste_request_text(self):
        try:
            text = self.clipboard_get()
        except tk.TclError:
            messagebox.showwarning("剪贴板为空", "没有读取到可粘贴的文本。")
            return
        if text.strip():
            self.raw_text.insert("end", ("\n" if self.raw_text.get("1.0", "end").strip() else "") + text.strip())

    def load_request_text(self):
        path = filedialog.askopenfilename(
            title="导入需求文本",
            filetypes=[("Text", "*.txt *.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            text = Path(path).read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = Path(path).read_text(encoding="gb18030")
        self.raw_text.delete("1.0", "end")
        self.raw_text.insert("1.0", text)

    def clear_request_text(self):
        self.raw_text.delete("1.0", "end")

    def insert_sample_request(self):
        sample = """Hair Tail
Bluegill
Glide Bait
义乌 双节
纤维毛尾
蓝鲫鱼
140mm
10000 pcs 1.63
10000 pcs 1.48
10000 pcs 5.03"""
        self.raw_text.delete("1.0", "end")
        self.raw_text.insert("1.0", sample)

    def document_state(self):
        self.collect_settings()
        return {
            "document_no": self.document_no_var.get().strip() or default_doc_no(self.doc_type.get()),
            "document_type": self.doc_type.get(),
            "buyer": {key: var.get().strip() for key, var in self.buyer_vars.items()},
            "terms": self.get_terms_state(),
            "raw_text": self.raw_text.get("1.0", "end").strip(),
            "items": [asdict(item) for item in self.items],
            "settings": self.config_data,
        }

    def apply_document_state(self, state):
        self.doc_type.set(state.get("document_type", "quotation"))
        self.document_no_var.set(state.get("document_no") or default_doc_no(self.doc_type.get()))
        for key, var in self.buyer_vars.items():
            var.set(state.get("buyer", {}).get(key, ""))
        self.raw_text.delete("1.0", "end")
        self.raw_text.insert("1.0", state.get("raw_text", ""))
        settings = state.get("settings")
        if isinstance(settings, dict):
            self.config_data.update(settings)
            self._load_settings_into_ui()
        self.apply_terms_state(state.get("terms", {}))
        self.items = [Item(**self._normalize_item(item)) for item in state.get("items", [])]
        self.selected_index = None
        self._refresh_items()

    def save_draft(self):
        DRAFT_DIR.mkdir(exist_ok=True)
        name = self.document_no_var.get().strip() or default_doc_no(self.doc_type.get())
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
        path = filedialog.asksaveasfilename(initialdir=str(DRAFT_DIR), initialfile=f"{safe_name}.json",
                                            defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not path:
            return
        Path(path).write_text(json.dumps(self.document_state(), ensure_ascii=False, indent=2), encoding="utf-8")
        messagebox.showinfo("草稿已保存", f"已保存：\n{path}")

    def load_draft(self):
        path = filedialog.askopenfilename(initialdir=str(DRAFT_DIR), filetypes=[("JSON", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            state = json.loads(Path(path).read_text(encoding="utf-8"))
            self.apply_document_state(state)
        except Exception as exc:
            messagebox.showerror("载入失败", f"草稿文件无法读取：\n{exc}")

    def extract_buyer_from_text(self, raw):
        if not raw:
            return
        patterns = {
            "buyer_email": r"[\w.+-]+@[\w.-]+\.\w+",
            "buyer_phone": r"(?:phone|tel|mobile|电话|手机)[:：\s]*([+\d][\d\s().-]{5,})",
            "buyer_name": r"(?:buyer|customer|client|客户|买方)[:：\s]*([^\n\r]+)",
            "buyer_contact": r"(?:contact|attn|联系人)[:：\s]*([^\n\r]+)",
            "buyer_address": r"(?:address|地址)[:：\s]*([^\n\r]+)",
        }
        for key, pattern in patterns.items():
            var = self.buyer_vars.get(key)
            if not var or var.get().strip():
                continue
            match = re.search(pattern, raw, re.I)
            if match:
                value = match.group(1) if match.groups() else match.group(0)
                var.set(value.strip(" :："))

    def ai_fill(self):
        raw = self.raw_text.get("1.0", "end").strip()
        if not raw:
            messagebox.showwarning("缺少内容", "请先粘贴需要整理的商品文本。")
            return
        self.extract_buyer_from_text(raw)
        key = self.api_key_var.get().strip()
        if key:
            try:
                parsed = self.call_deepseek(raw, key)
                self.items = [Item(**self._normalize_item(x)) for x in parsed]
                self._refresh_items()
                return
            except Exception as exc:
                messagebox.showwarning("AI整理失败", f"DeepSeek 调用失败，已改用本地解析。\n\n{exc}")
        self.items = self.local_parse(raw)
        self._refresh_items()

    def call_deepseek(self, raw, api_key):
        prompt = f"""
请把下面外贸商品报价信息整理为 JSON 数组。只返回 JSON，不要解释。
字段：name_en, name_cn, spec, material, usage, cbm, quantity, unit, unit_price。
cbm、quantity 和 unit_price 使用数字；没有时用 0。unit 默认 pcs。
文本：
{raw}
"""
        payload = {
            "model": self.config_data.get("deepseek_model", "deepseek-chat"),
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.1,
        }
        req = urllib.request.Request(
            self.config_data.get("deepseek_api_url", DEFAULT_CONFIG["deepseek_api_url"]),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=40) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        content = data["choices"][0]["message"]["content"].strip()
        content = re.sub(r"^```(?:json)?|```$", "", content, flags=re.I | re.M).strip()
        result = json.loads(content)
        if not isinstance(result, list):
            raise ValueError("AI 返回内容不是商品数组")
        return result

    def _normalize_item(self, data):
        return {
            "picture_label": "",
            "name_en": str(data.get("name_en", "")).strip(),
            "name_cn": str(data.get("name_cn", "")).strip(),
            "spec": str(data.get("spec", "")).strip(),
            "material": str(data.get("material", "")).strip(),
            "usage": str(data.get("usage", "")).strip(),
            "cbm": float(data.get("cbm") or 0),
            "quantity": float(data.get("quantity") or 0),
            "unit": str(data.get("unit") or "pcs").strip(),
            "unit_price": float(data.get("unit_price") or 0),
            "image_path": str(data.get("image_path") or "").strip(),
        }

    def local_parse(self, raw):
        lines = [x.strip(" |") for x in raw.splitlines() if x.strip(" |")]
        stop_words = ("total", "总计", "Total in Words", "人民币", "customer", "buyer", "client",
                      "email", "phone", "tel", "mobile", "address", "contact", "客户", "买方",
                      "邮箱", "电话", "手机", "地址", "联系人")
        product_lines = [x for x in lines if not any(w.lower() in x.lower() for w in stop_words)]
        product_text = "\n".join(product_lines)
        price_matches = re.findall(r"(?:USD|\$|单价|unit\s*price)?\s*(\d+\.\d{1,4})(?!\d)", product_text, re.I)
        prices = [float(x) for x in price_matches]
        quantities = [float(x) for x in re.findall(r"(\d{2,})(?=\s*(?:pcs|sets|units|unit|个|套)\b)", product_text, re.I)]
        units = re.findall(r"\d{2,}\s*(pcs|sets|units|unit|个|套)\b", product_text, re.I)
        cbms = [float(x) for x in re.findall(r"(?:cbm|体积|立方)[:：\s]*(\d+(?:\.\d+)?)", product_text, re.I)]
        if not quantities:
            quantities = [10000.0] * min(6, max(1, len(product_lines) // 2))
        names_en = []
        names_cn = []
        specs = []
        for line in product_lines:
            if re.search(r"\d{2,}\s*(?:pcs|sets|units|unit|个|套)\b", line, re.I):
                continue
            if re.fullmatch(r"\d+(?:\.\d+)?|pcs|sets|units?", line, re.I):
                continue
            if len(line) <= 1:
                continue
            if re.search(r"[\u4e00-\u9fff]", line):
                names_cn.append(line)
            elif re.search(r"\d", line):
                specs.append(line)
            else:
                names_en.append(line)
        count_seed = len(prices) or len(quantities) or max(len(names_en), len(names_cn), 1)
        count = min(6, count_seed)
        items = []
        for i in range(count):
            en = names_en[i] if i < len(names_en) else f"Product {i+1}"
            cn = names_cn[i] if i < len(names_cn) else ""
            spec = specs[i] if i < len(specs) else ""
            price = prices[i] if i < len(prices) else 0
            qty = quantities[i] if i < len(quantities) else quantities[0]
            unit = units[i] if i < len(units) else (units[0] if units else "pcs")
            cbm = cbms[i] if i < len(cbms) else 0
            items.append(Item(name_en=en, name_cn=cn, spec=spec, cbm=cbm, quantity=qty, unit=unit, unit_price=price))
        return items

    def convert_rmb_to_usd(self):
        try:
            rate = Decimal(self.rate_var.get().strip())
            if rate <= 0:
                raise ValueError
        except Exception:
            messagebox.showerror("汇率错误", "请填写正确的美元兑人民币汇率。")
            return
        for item in self.items:
            item.unit_price = float(money(Decimal(str(item.unit_price)) / rate))
        self._refresh_items()

    def _refresh_items(self):
        self.tree.delete(*self.tree.get_children())
        self.tk_images = []
        total = Decimal("0")
        for i, item in enumerate(self.items):
            total += item.subtotal
            pic = f"商品{i+1}图片 ✓" if item.image_path else f"商品{i+1}图片"
            self.tree.insert("", "end", iid=str(i), values=(
                pic, item.name_en, item.name_cn, item.spec, item.material, item.usage, f"{item.cbm:g}",
                f"{item.quantity:g}", item.unit,
                f"{money(item.unit_price):,.2f}", f"{item.subtotal:,.2f}",
            ))
        self.total_var.set(f"Total / 总计: USD {total:,.2f}")
        self._refresh_images()
        self._refresh_preview()

    def _refresh_preview(self):
        self.preview_text.delete("1.0", "end")
        title = "QUOTATION" if self.doc_type.get() == "quotation" else "PROFORMA INVOICE"
        total = sum((item.subtotal for item in self.items), Decimal("0"))
        buyer_name = self.buyer_vars.get("buyer_name", tk.StringVar()).get()
        terms = self.get_terms_state()
        lines = [title, f"Document No.: {self.document_no_var.get().strip()}", f"Date: {today()}",
                 "", "Seller:", self.config_data.get("company_en", ""), self.config_data.get("company_cn", ""),
                 "", "Buyer:", buyer_name or "Customer / 客户", "", "Items:"]
        for i, item in enumerate(self.items, 1):
            extras = " | ".join(x for x in [
                f"Material: {item.material}" if item.material else "",
                f"Usage: {item.usage}" if item.usage else "",
                f"CBM: {item.cbm:g}" if item.cbm else "",
            ] if x)
            lines.append(f"{i}. {item.name_en or item.name_cn} | {extras} | {item.quantity:g} {item.unit} x USD {money(item.unit_price):,.2f} = USD {item.subtotal:,.2f}")
        lines.extend([
            "",
            f"Total: USD {total:,.2f}",
            "",
            "Terms:",
            f"Payment: {terms['payment_terms']}",
            f"Trade: {terms['trade_terms']}",
            f"Delivery: {terms['delivery_time']}",
        ])
        if terms.get("remarks"):
            lines.extend(["", "Remarks:", terms["remarks"]])
        self.preview_text.insert("1.0", "\n".join(lines))

    def _refresh_images(self):
        for i, label in enumerate(self.image_cards):
            if i < len(self.items) and self.items[i].image_path:
                try:
                    img = Image.open(self.items[i].image_path)
                    img.thumbnail((170, 110))
                    tk_img = ImageTk.PhotoImage(img)
                    self.tk_images.append(tk_img)
                    label.configure(image=tk_img, text="")
                except Exception:
                    label.configure(image="", text=f"商品{i+1}\n图片无效")
            else:
                label.configure(image="", text=f"商品{i+1}\n点击选择图片")

    def on_select_item(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            return
        self.selected_index = int(sel[0])
        item = self.items[self.selected_index]
        self.edit_vars["name_en"].set(item.name_en)
        self.edit_vars["name_cn"].set(item.name_cn)
        self.edit_vars["spec"].set(item.spec)
        self.edit_vars["material"].set(item.material)
        self.edit_vars["usage"].set(item.usage)
        self.edit_vars["cbm"].set(f"{item.cbm:g}")
        self.edit_vars["quantity"].set(f"{item.quantity:g}")
        self.edit_vars["unit"].set(item.unit)
        self.edit_vars["unit_price"].set(str(item.unit_price))

    def edit_selected_item(self, _event=None):
        self.update_item()

    def _item_from_edit(self):
        try:
            qty = float(self.edit_vars["quantity"].get() or 0)
            price = float(self.edit_vars["unit_price"].get() or 0)
            cbm = float(self.edit_vars["cbm"].get() or 0)
        except ValueError:
            messagebox.showerror("数字错误", "数量、单价和 CBM 必须是数字。")
            return None
        image = ""
        if self.selected_index is not None and self.selected_index < len(self.items):
            image = self.items[self.selected_index].image_path
        return Item(
            name_en=self.edit_vars["name_en"].get().strip(),
            name_cn=self.edit_vars["name_cn"].get().strip(),
            spec=self.edit_vars["spec"].get().strip(),
            material=self.edit_vars["material"].get().strip(),
            usage=self.edit_vars["usage"].get().strip(),
            cbm=cbm,
            quantity=qty,
            unit=self.edit_vars["unit"].get().strip() or "pcs",
            unit_price=price,
            image_path=image,
        )

    def add_item(self):
        item = self._item_from_edit()
        if item:
            item.image_path = ""
            self.items.append(item)
            self._refresh_items()

    def update_item(self):
        if self.selected_index is None or self.selected_index >= len(self.items):
            messagebox.showwarning("未选择", "请先选择要更新的商品行。")
            return
        item = self._item_from_edit()
        if item:
            self.items[self.selected_index] = item
            self._refresh_items()

    def delete_item(self):
        if self.selected_index is None or self.selected_index >= len(self.items):
            return
        del self.items[self.selected_index]
        self.selected_index = None
        self._refresh_items()

    def choose_selected_image(self):
        if self.selected_index is None:
            messagebox.showwarning("未选择", "请先在中间表格选择商品行。")
            return
        self.choose_image(self.selected_index)

    def choose_image(self, idx):
        if idx >= len(self.items):
            messagebox.showwarning("缺少商品", "请先添加对应商品行。")
            return
        path = filedialog.askopenfilename(
            title="选择商品图片",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")]
        )
        if path:
            self.items[idx].image_path = path
            self._refresh_items()

    def bulk_add_images(self):
        if not self.items:
            messagebox.showwarning("缺少商品", "请先整理或添加商品行。")
            return
        paths = filedialog.askopenfilenames(
            title="按商品顺序选择图片",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")]
        )
        if not paths:
            return
        start = self.selected_index if self.selected_index is not None else 0
        for offset, path in enumerate(paths):
            idx = start + offset
            if idx >= len(self.items):
                break
            self.items[idx].image_path = path
        self._refresh_items()

    def clear_selected_image(self):
        if self.selected_index is None or self.selected_index >= len(self.items):
            return
        self.items[self.selected_index].image_path = ""
        self._refresh_items()

    def export_excel(self):
        if not self.items:
            messagebox.showwarning("缺少商品", "请先添加或整理商品。")
            return
        self.collect_settings()
        terms = self.get_terms_state()
        EXPORT_DIR.mkdir(exist_ok=True)
        doc_no = self.document_no_var.get().strip() or default_doc_no(self.doc_type.get())
        default_name = f"{doc_no}.xlsx"
        path = filedialog.asksaveasfilename(initialdir=str(EXPORT_DIR), initialfile=default_name,
                                            defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if not path:
            return
        wb = Workbook()
        ws = wb.active
        ws.title = "PI"
        title = "QUOTATION / 报价单" if self.doc_type.get() == "quotation" else "PROFORMA INVOICE / 形式发票"
        ws.merge_cells("A1:K1")
        ws["A1"] = title
        ws["A1"].font = Font(bold=True, size=18, color="1F4E79")
        ws["A1"].alignment = Alignment(horizontal="center")
        ws["A2"] = "Document No."
        ws["B2"] = doc_no
        ws["F2"] = "Date"
        ws["G2"] = today()
        ws["A4"] = "Seller"
        ws["B4"] = self.config_data.get("company_en") or self.config_data.get("company_cn")
        ws["A5"] = "Buyer"
        ws["B5"] = self.buyer_vars.get("buyer_name", tk.StringVar()).get()
        headers = ["No.", "Product EN", "Product CN", "Spec", "Material", "Usage", "CBM", "Qty", "Unit", "Unit Price", "Amount"]
        start_row = 7
        for col, header in enumerate(headers, 1):
            cell = ws.cell(start_row, col, header)
            cell.font = Font(bold=True, color="1F4E79")
            cell.fill = PatternFill("solid", fgColor="EAF1F8")
            cell.alignment = Alignment(horizontal="center")
        thin = Side(style="thin", color="CFD7DF")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        total = Decimal("0")
        for row_idx, item in enumerate(self.items, start_row + 1):
            total += item.subtotal
            values = [row_idx - start_row, item.name_en, item.name_cn, item.spec, item.material,
                      item.usage, item.cbm, item.quantity, item.unit,
                      float(money(item.unit_price)), float(item.subtotal)]
            for col, value in enumerate(values, 1):
                cell = ws.cell(row_idx, col, value)
                cell.border = border
                cell.alignment = Alignment(vertical="center", wrap_text=True)
                if col in (7, 8, 10, 11):
                    cell.number_format = '#,##0.00'
        total_row = start_row + len(self.items) + 1
        ws.cell(total_row, 10, "Total / 总计").font = Font(bold=True)
        ws.cell(total_row, 11, float(total)).font = Font(bold=True, color="B45309")
        ws.cell(total_row, 11).number_format = '#,##0.00'
        for col in range(1, 12):
            ws.cell(total_row, col).border = border
        terms_start = total_row + 2
        term_rows = [
            ("Payment Terms / 付款方式", terms["payment_terms"]),
            ("Trade Terms / 贸易条款", terms["trade_terms"]),
            ("Delivery Time / 交期", terms["delivery_time"]),
            ("Validity Days / 有效期天数", terms["validity_days"]),
        ]
        if terms.get("remarks"):
            term_rows.append(("Remarks / 备注", terms["remarks"]))
        for offset, (label, value) in enumerate(term_rows):
            row_no = terms_start + offset
            ws.cell(row_no, 1, label).font = Font(bold=True, color="6E6E73")
            ws.cell(row_no, 2, value)
            ws.merge_cells(start_row=row_no, start_column=2, end_row=row_no, end_column=11)
            ws.cell(row_no, 2).alignment = Alignment(wrap_text=True, vertical="top")
        widths = [8, 24, 20, 18, 16, 18, 10, 12, 10, 14, 16]
        for idx, width in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(idx)].width = width
        wb.save(path)
        messagebox.showinfo("Excel已导出", f"已生成：\n{path}")

    def _pdf_styles(self):
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        styles = getSampleStyleSheet()
        normal = ParagraphStyle("CN", parent=styles["Normal"], fontName="STSong-Light", fontSize=9.2, leading=13,
                                textColor=colors.HexColor("#1d1d1f"))
        small = ParagraphStyle("SmallCN", parent=normal, fontSize=8.2, leading=11,
                               textColor=colors.HexColor("#6e6e73"))
        title = ParagraphStyle("TitleCN", parent=normal, fontSize=24, leading=29, alignment=TA_LEFT,
                               textColor=colors.HexColor("#1d1d1f"), spaceAfter=4)
        right = ParagraphStyle("RightCN", parent=normal, alignment=TA_RIGHT)
        center = ParagraphStyle("CenterCN", parent=normal, alignment=TA_CENTER)
        return normal, small, title, right, center

    def p(self, text, style):
        return Paragraph(str(text or "").replace("\n", "<br/>"), style)

    def confirm_document_ready(self):
        warnings = []
        if not (self.config_data.get("company_en") or self.config_data.get("company_cn")):
            warnings.append("卖方公司名称为空")
        if not self.buyer_vars.get("buyer_name", tk.StringVar()).get().strip():
            warnings.append("买方客户名称为空")
        zero_price = [str(i + 1) for i, item in enumerate(self.items) if money(item.unit_price) == 0]
        if zero_price:
            warnings.append(f"第 {', '.join(zero_price)} 行单价为 0")
        if not warnings:
            return True
        return messagebox.askyesno("生成前检查", "发现以下项目：\n\n" + "\n".join(warnings) + "\n\n仍然生成 PDF？")

    def generate_pdf(self):
        if not self.items:
            messagebox.showwarning("缺少商品", "请先添加或整理商品。")
            return
        self.collect_settings()
        if not self.confirm_document_ready():
            return
        terms_state = self.get_terms_state()
        self.save_config()
        EXPORT_DIR.mkdir(exist_ok=True)
        default_name = f"{self.document_no_var.get().strip() or default_doc_no(self.doc_type.get())}.pdf"
        path = filedialog.asksaveasfilename(initialdir=str(EXPORT_DIR), initialfile=default_name,
                                            defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        normal, small, title_style, right, center = self._pdf_styles()
        doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=16 * mm, leftMargin=16 * mm,
                                topMargin=16 * mm, bottomMargin=16 * mm)
        story = []
        title_text = "Quotation / 报价单" if self.doc_type.get() == "quotation" else "Proforma Invoice / 形式发票"
        doc_no = self.document_no_var.get().strip() or default_doc_no(self.doc_type.get())
        meta = f"<font color='#6e6e73'>Document No.</font> {doc_no}<br/><font color='#6e6e73'>Date</font> {today()}<br/><font color='#6e6e73'>Valid Until</font> {add_days(terms_state.get('validity_days', 15))}<br/><font color='#6e6e73'>Currency</font> USD"
        logo_path = self.config_data.get("logo_path", "")
        logo_cell = ""
        if logo_path and Path(logo_path).exists():
            try:
                logo_cell = PdfImage(logo_path, width=28 * mm, height=18 * mm, kind="proportional")
            except Exception:
                logo_cell = ""
        header = Table([[logo_cell, self.p(title_text, title_style), self.p(meta, right)]],
                       colWidths=[30 * mm, 86 * mm, 50 * mm])
        header.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LINEBELOW", (0, 0), (-1, -1), 0.6, colors.HexColor("#e5e5ea")),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ]))
        story.append(header)
        story.append(Spacer(1, 12))
        seller_lines = [self.config_data.get("company_en"), self.config_data.get("company_cn"),
                        self.config_data.get("address_en"), self.config_data.get("address_cn"),
                        self.config_data.get("email"), self.config_data.get("website")]
        if self.config_data.get("show_phone"):
            seller_lines.append(self.config_data.get("phone"))
        buyer_lines = [
            self.buyer_vars.get("buyer_name", tk.StringVar()).get(),
            self.buyer_vars.get("buyer_contact", tk.StringVar()).get(),
            self.buyer_vars.get("buyer_address", tk.StringVar()).get(),
            self.buyer_vars.get("buyer_email", tk.StringVar()).get(),
            self.buyer_vars.get("buyer_phone", tk.StringVar()).get(),
        ]
        party = Table([
            [self.p("<font color='#6e6e73'>Seller / 卖方</font>", small), self.p("<font color='#6e6e73'>Buyer / 买方</font>", small)],
            [self.p("<br/>".join(x for x in seller_lines if x), normal),
             self.p("<br/>".join(x for x in buyer_lines if x) or "Customer / 客户", normal)],
        ], colWidths=[83 * mm, 83 * mm])
        party.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fbfbfd")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#e5e5ea")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e5e5ea")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("PADDING", (0, 0), (-1, -1), 9),
        ]))
        story.append(party)
        story.append(Spacer(1, 12))

        data = [[self.p("No.", center), self.p("Picture", center), self.p("Product", center),
                 self.p("Spec", center), self.p("Qty", center), self.p("Unit", center),
                 self.p("Unit Price", center), self.p("Amount", center)]]
        for i, item in enumerate(self.items, 1):
            product_parts = [item.name_en, item.name_cn]
            detail_parts = []
            if item.material:
                detail_parts.append(f"Material / 材料: {item.material}")
            if item.usage:
                detail_parts.append(f"Usage / 用途: {item.usage}")
            if item.cbm:
                detail_parts.append(f"CBM / 体积: {item.cbm:g}")
            if detail_parts:
                product_parts.append("<font color='#6e6e73'>" + "<br/>".join(detail_parts) + "</font>")
            product = "<br/>".join(x for x in product_parts if x)
            img_cell = self.p("No image", small)
            if item.image_path and Path(item.image_path).exists():
                try:
                    img_cell = PdfImage(item.image_path, width=21 * mm, height=21 * mm, kind="proportional")
                except Exception:
                    img_cell = self.p("Image error", small)
            data.append([self.p(i, center), img_cell, self.p(product, normal), self.p(item.spec, small),
                         self.p(f"{item.quantity:g}", center), self.p(item.unit, center),
                         self.p(f"USD {money(item.unit_price):,.2f}", right),
                         self.p(f"USD {item.subtotal:,.2f}", right)])
        widths = [8 * mm, 22 * mm, 40 * mm, 24 * mm, 14 * mm, 12 * mm, 23 * mm, 25 * mm]
        table = Table(data, colWidths=widths, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f5f5f7")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#6e6e73")),
            ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#e5e5ea")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("PADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(table)
        total = sum((item.subtotal for item in self.items), Decimal("0"))
        story.append(Spacer(1, 12))
        total_table = Table([[self.p("<font color='#6e6e73'>Total / 总计</font>", right),
                              self.p(f"<font size='15'><b>USD {total:,.2f}</b></font>", right)]],
                            colWidths=[126 * mm, 40 * mm])
        total_table.setStyle(TableStyle([
            ("LINEABOVE", (0, 0), (-1, 0), 0.6, colors.HexColor("#1d1d1f")),
            ("TOPPADDING", (0, 0), (-1, 0), 8),
        ]))
        story.append(total_table)
        terms = Table([
            [self.p("<font color='#6e6e73'>Payment Terms / 付款方式</font>", small), self.p(terms_state.get("payment_terms"), normal)],
            [self.p("<font color='#6e6e73'>Trade Terms / 贸易条款</font>", small), self.p(terms_state.get("trade_terms"), normal)],
            [self.p("<font color='#6e6e73'>Delivery Time / 交期</font>", small), self.p(terms_state.get("delivery_time"), normal)],
        ], colWidths=[42 * mm, 124 * mm])
        terms.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#e5e5ea")),
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fbfbfd")),
            ("PADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(Spacer(1, 14))
        story.append(terms)
        if terms_state.get("remarks"):
            story.append(Spacer(1, 8))
            remarks_table = Table([
                [self.p("<font color='#6e6e73'>Remarks / 备注</font>", small),
                 self.p(terms_state.get("remarks"), normal)]
            ], colWidths=[42 * mm, 124 * mm])
            remarks_table.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#e5e5ea")),
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fbfbfd")),
                ("PADDING", (0, 0), (-1, -1), 8),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
            story.append(remarks_table)
        story.append(Spacer(1, 24))
        signature_path = self.config_data.get("signature_path", "")
        sign_content = self.p("Authorized Signature / 授权签名: __________________________", right)
        if signature_path and Path(signature_path).exists():
            try:
                sign_content = PdfImage(signature_path, width=45 * mm, height=24 * mm, kind="proportional")
            except Exception:
                pass
        sign_table = Table([["", sign_content], ["", self.p("Authorized Signature / 授权签名", center)]],
                           colWidths=[110 * mm, 60 * mm])
        sign_table.setStyle(TableStyle([("ALIGN", (1, 0), (1, -1), "CENTER"),
                                        ("VALIGN", (1, 0), (1, -1), "BOTTOM")]))
        story.append(sign_table)
        doc.build(story)
        messagebox.showinfo("PDF已生成", f"已生成：\n{path}")


if __name__ == "__main__":
    try:
        app = PiGeneratorApp()
        app.mainloop()
    except Exception as exc:
        messagebox.showerror("启动失败", str(exc))
        raise
