#!/bin/zsh -f
cd "$(dirname "$0")"

if [ ! -x ".venv/bin/python" ]; then
  echo "还没有安装运行环境，正在打开首次安装..."
  ./首次安装.command
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "运行环境仍未就绪，无法启动。"
  read -k 1 "?按任意键退出..."
  exit 1
fi

.venv/bin/python - <<'PY'
missing = []
for package, module in [("pillow", "PIL"), ("reportlab", "reportlab"), ("openpyxl", "openpyxl")]:
    try:
        __import__(module)
    except Exception:
        missing.append(package)
if missing:
    print("缺少依赖：" + ", ".join(missing))
    raise SystemExit(2)
PY

if [ $? -ne 0 ]; then
  echo "正在补装依赖..."
  source .venv/bin/activate
  python -m pip install pillow reportlab openpyxl
fi

.venv/bin/python pi_generator_mac.py
