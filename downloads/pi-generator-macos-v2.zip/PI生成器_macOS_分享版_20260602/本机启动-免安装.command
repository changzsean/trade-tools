#!/bin/zsh -f
cd "$(dirname "$0")"

PY="/Users/changzheng/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"

if [ ! -x "$PY" ]; then
  echo "这台电脑没有找到内置运行环境。"
  echo "请改用「首次安装.command」安装通用运行环境。"
  read -k 1 "?按任意键退出..."
  exit 1
fi

"$PY" pi_generator_mac.py
