#!/bin/zsh -f
cd "$(dirname "$0")"

echo "正在准备 PI 生成器运行环境..."

PYTHON_BIN=""
for candidate in \
  "/opt/homebrew/bin/python3" \
  "/usr/local/bin/python3" \
  "/Library/Frameworks/Python.framework/Versions/3.12/bin/python3" \
  "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3" \
  "/Library/Frameworks/Python.framework/Versions/3.10/bin/python3"
do
  if [ -x "$candidate" ]; then
    PYTHON_BIN="$candidate"
    break
  fi
done

if [ -z "$PYTHON_BIN" ]; then
  echo ""
  echo "没有找到可用的 Python 3。"
  echo ""
  echo "请安装 Python 3 官方版，然后重新双击本文件："
  echo "https://www.python.org/downloads/macos/"
  echo ""
  echo "注意：不要点击系统弹出的“命令行开发者工具”安装。这个软件不需要 git。"
  echo ""
  read -k 1 "?按任意键退出..."
  exit 1
fi

"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    print("Python 版本过低，请安装 Python 3.10 或更新版本。")
    raise SystemExit(1)
print("Python OK:", sys.version)
PY

if [ $? -ne 0 ]; then
  read -k 1 "?按任意键退出..."
  exit 1
fi

"$PYTHON_BIN" -m venv .venv
if [ $? -ne 0 ]; then
  echo ""
  echo "创建运行环境失败。请确认 Python 3 安装完整。"
  read -k 1 "?按任意键退出..."
  exit 1
fi

source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install --only-binary=:all: pillow reportlab openpyxl

echo ""
echo "安装完成。以后双击「启动PI生成器.command」即可使用。"
echo ""
read -k 1 "?按任意键退出..."
