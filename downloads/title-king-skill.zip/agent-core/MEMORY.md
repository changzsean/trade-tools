# Memory
> `diary/...` in Diary sources = local files under `agent-core/diary/`, not URLs; do not fetch over HTTP.

## Diary sources
- Optimized 350*400mm Silicone Rubber Heater titles using SRF layout and IP65/3M Adhesive attributes. [diary/2026-05-06.md](diary/2026-05-06.md)

## 🪪 Personal Information
- Role: Alibaba International Station Title Expert (Number One Team).
- Core Competency: SEO title optimization, AEO (Answer Engine Optimization), and AI-search FAQ generation for B2B/B2C electronics, machinery, renewable energy, and beauty tools.

## 🌿 Personal Habits & Preferences
- **Title Length**: Strictly 120-128 characters to maximize index weight.
- **Keyword Placement**: Core transaction keywords must occupy the last 10-20 characters.
- **Formatting**: English titles in Title Case; mandatory Chinese translation for every title.
- **Delivery Standard**: Default batch size of 20 titles, grouped by scenario/attribute, with design intent analysis.
- **Language Rules**: No word repetition >2 times; ban vague adjectives (e.g., "Good", "Best").
- **FAQ Style**: Optimized for AI search visibility (AEO), focusing on direct answers, data anchors, and technical protocols (PPS, PD 3.0).

## 👥 People & Pets
- (none recorded)

## 💼 Work & Projects
- **[Number One Title SOP]**: Active framework enforcing SRF layout (Attribute/Scenario + Feature/Value + Core Keyword).
- **[Recent Copywriting Tasks]**:
    - **Silicone Rubber Heater**: Optimized 350*400mm variants emphasizing IP65 rating and 3M adhesive backing.
    - **Logitech G435 Headset**: Optimized titles for wireless gaming features; created AEO-compliant FAQs for AI search extraction.
    - **20W iPhone Chargers**: Focused on compatibility (iPhone 17/16/15), technical specs (PPS, GaN, ETL, CE), and AEO FAQs.
    - **Custom Badges**: Categorized by enamel, embroidery, and military attributes using SRF layout.
    - **iPhone Cases**: Focused on MagSafe, material specs, and protection standards; defined 10 high-weight custom attributes (e.g., N52 magnets).
    - **Lash Clusters**: Categorized by DIY, segmented, wholesale, and kit attributes.
    - **Industrial PH Meters**: Segmented into online, portable, lab, and sensor types with strict SRF adherence.
    - **Luggage Suitcase**: Categorized by business tech, family sets, durability, and luxury frames.
    - **Photovoltaic Solar Energy**: Focused on N-Type/Topcon tech, bifacial modules, and aesthetic residential panels.
    - **Solar Street Light**: Split into all-in-one, high-power engineering, smart sensor, and die-cast aluminum categories.
    - **Pipe Bending Machine**: Focused on "Customized" and "Industrial" attributes.
    - **Chainsaw**: Emphasized "Ready to Ship," "Low MOQ," and "Factory Price."
- **[Keyword Pools]**: Maintained specific pools for Industrial Heating, Consumer Electronics, Renewable Energy, Gift/Packaging, and Beauty Tools sectors.

## 📈 Finance & News Interests
- **B2B E-commerce Trends**: Focus on high-conversion triggers like "Low MOQ," "Ready to Ship," and certification compliance (ETL, CE).
- **AEO Strategy**: Prioritizing structured FAQs and direct answers for AI-driven search engines over traditional keyword stuffing.
- **Industrial Machinery SEO**: Prioritizing technical parameters (voltage, material, capacity) in search indexing.
- **Renewable Energy SEO**: Emphasis on specific tech specs (N-Type, Topcon, Bifacial) for solar products.
- **Consumer Tech SEO**: Emphasis on charging protocols (PD, PPS, GaN) and compatibility specifics for AI-driven search queries.
