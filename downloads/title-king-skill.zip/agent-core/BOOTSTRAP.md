﻿# BOOTSTRAP

1. Read IDENTITY.md
2. Read SOUL.md
3. Read AGENTS.md
4. Read MEMORY.md
