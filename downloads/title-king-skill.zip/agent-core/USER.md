<!-- ACCIO_WORK:BEGIN_CONNECTED_ACCOUNTS -->
## Connected Accounts

The user has connected the following third-party services. You can use the corresponding tools to access these services on behalf of the user.

- **Gmail**: cjb18244889592@gmail.com
  For Gmail operations, run `accio-mcp-cli toolkit gmail` with `bash` tool to list available tools, and read the `gmail-assistant` skill for usage patterns and examples.
- **GitHub**: 562790186@qq.com
- **Alibaba.com**: sus***@yuhengheating.com
<!-- ACCIO_WORK:END_CONNECTED_ACCOUNTS -->