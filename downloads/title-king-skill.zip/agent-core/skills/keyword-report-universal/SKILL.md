---
name: keyword-report-universal
description: 跨境电商关键词月报生成工具（通用版）。适用任意品类，AI自动研究关键词数据并生成完整Excel月报，含关键词分级清单、爆发词、标题模板、季节日历、竞品反查、买家VOC、禁止词+SOP，共8张Sheet。触发词：生成关键词月报、keyword report、帮我做关键词分析、出一份关键词报告。
---

# 跨境关键词月报 Skill（通用版）

## 触发词
"生成关键词月报"、"帮我做关键词分析"、"出一份XX产品的关键词报告"

## 执行流程

**Step 1 — 获取产品信息**
如果用户没有说明产品，先问：
> "请告诉我你的产品品类和主要销售平台（阿里国际站/亚马逊/独立站）？"

**Step 2 — AI自动研究关键词**
用 web_search 搜索以下数据：
- `{产品} keyword search volume Amazon 2025 2026`
- `{产品} packaging buyer demand Alibaba 2025 2026`
- `{产品} Google Trends rising keywords`
- `{产品} market size growth rate 2025`

**Step 3 — 生成Excel报告**
基于研究结果，用 Python + openpyxl 生成8张Sheet的完整报告，结构如下：

| Sheet | 内容 |
|-------|------|
| 使用指南 | 目录+数据来源 |
| 关键词分级清单 | A/B/C/D四级，含平台数据+季节标注 |
| 爆发词TOP8 | 当前竞争少、增速快的黄金词 |
| 标题模板 | 128字符模板，按产品线分类 |
| 亚马逊买家洞察 | 热搜词+VOC痛点 |
| 竞品标题反查 | 词频统计+差异化机会 |
| 季节词日历 | 全年12个月推广时间表 |
| 禁止词+月度SOP | 禁止词+每月执行步骤 |

**Step 4 — 输出文件**
保存到桌面：`{产品}关键词月报_{年月}.xlsx`
Windows用WPS打开，Mac用系统默认程序。

## 关键词分级规则（AI填充时遵守）
- **A级**：品类核心词，搜索量最大，每个产品必放
- **B级**：材质/结构/工艺词，与产品直接相关
- **C级**：场景/节日/人群词，按季节选放
- **D级**：长尾精准词，用于P4P/竞价广告

## 标题公式
```
[属性词] + [核心产品词] + [场景/卖点词] + [定制词] + [同义变体]
≤ 128字符
```

## 禁止词（通用，所有品类适用）
high quality / best price / hot sale / good quality / best seller / free sample / factory price / fast delivery / 年份词
