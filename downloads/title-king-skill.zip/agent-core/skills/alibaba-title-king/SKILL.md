---
name: alibaba-title-king
description: >
  Professional Alibaba.com product title generation and optimization following the "Number One" SEO standard.
  Use when generating or rewriting product titles to achieve 128 characters, SRF layout, and core keyword positioning.
  Keywords: Alibaba title, SEO title, product title, 128 characters, SRF layout.
user-invocable: true
always_apply: false
---

# Alibaba Title King - 阿里国际站标题专家

Use this skill when the user asks to "Generate product titles", "Write Alibaba titles", or mentions "Number One Title".

## 1. Core Standards (黄金准则)

1.  **128 Characters (字符极限)**: Aim for **120-128 characters**. Maximize weight for every byte.
2.  **SRF Layout (关键词布局)**:
    - **Prefix (Attribute/Scenario)**: Brand, material, application scenario, core pain points.
    - **Middle (Feature/Value)**: Technical parameters (e.g., "15kw 30kw"), certifications (CE, UL), high-frequency modifiers.
    - **End (Core Keyword)**: **MANDATORY** placement of the core transactional keyword in the **last 10-20 characters**.
3.  **Title Case**: All English words must have the first letter capitalized.
4.  **Bilingual Output**: Every English title must be accompanied by an accurate **Chinese translation**.
5.  **No Repetition**: Do not use the same word more than **twice** in a single title.
6.  **No Watery Words**: Strictly remove words like "Best", "Good", "Top Quality", "Cheap". Replace them with specific data or certifications.

## 2. Output Format (交付格式)

1.  **Group by Scenario**: Categorize titles based on product sub-types or usage scenarios.
2.  **Bilingual Listing**:
    - **English Title**
    - **Chinese Translation**
3.  **Design Analysis**: Provide "Design Intent" and "Keyword Distribution Analysis" for each title.
4.  **Quantity**: Default to **20 titles** per request to ensure full traffic coverage.

## 3. Pre-Flight Checklist (质量核查)

Before presenting, verify:
- [ ] Length: 120-128 characters?
- [ ] Core keyword at the very end?
- [ ] Bilingual translation included?
- [ ] No repeats > 2 times?
- [ ] Title Case applied?
- [ ] Watery words removed?
- [ ] Specific parameters (e.g., 220V, 50kw) included?

## 4. Activation
Triggered by keywords like "Alibaba Title", "Shredder title", or "Number One Title".
