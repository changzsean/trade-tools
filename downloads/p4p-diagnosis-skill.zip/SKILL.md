# alibaba-p4p-report

阿里巴巴国际站全站推广（直通车）优化执行表生成器。

输入店铺 aliId、活跃计划ID列表、日期范围，自动并行采集10+个数据源，生成包含6个Part的工业级HTML报告：账户整体、商品分级（含缩略图）、地域淘汰、关键词搜索词、时段/日度趋势、标签画像。

**触发场景：**
- "生成直通车报告"
- "生成全站推广优化表"
- "帮我出一份P4P执行表"
- "生成XXX店铺的直通车分析"
- "直通车7天/30天报告"

---

## ⚠️ Datasource 名称对照表（血泪教训，必须使用以下正确名称）

| 数据维度 | **正确名称** | 常见错误名称（勿用） |
|---------|------------|------------------|
| 账户整体 | `company_whole_site` | `company` |
| 计划维度 | `campaign_whole_site` | `campaign` |
| 商品维度 | `product_whole_site` | `product` |
| 地域维度 | `region_whole_site` | `region` |
| 关键词搜索词 | `searchword_whole_site` | `keyword` ❌ |
| 时段分布 | `hour_whole_site` | `hourly` ❌（500错误） |
| 标签定向 | `target_tag_whole_site` | `tag` ❌ / `audience` ❌（500错误） |

---

## 执行步骤

### Step 0：确定日期范围（唯一需要的输入）

**aliId 和计划ID 全部自动发现，无需用户提供。**

只需确认两个值：

| 参数 | 来源 | 默认值 |
|------|------|--------|
| `END_DATE` | 调用 `get_time` 工具获取今天日期 | 今天 |
| `PERIOD` | 从用户消息推断（"7天报告"→7，"30天"→30） | 30 |
| `OUTPUT_DIR` | 从用户消息推断，或默认 `project/` | `project/` |

**执行前必须调用 `get_time` 确认今天日期，不可使用系统提示中的静态日期。**

aliId 和活跃计划ID 由 `collect.py --auto-discover`（内置 Phase 0）自动完成：
1. 调 `icbu_ads_entity(entityType=campaign)` 拿活跃计划列表
2. 从计划 `memberId` 字段提取 aliId；若无则调 `icbu_company_info`
3. 结果写入 `{out_dir}/meta.json`，供 `generate.py` 复用

若自动发现失败（meta.json 缺字段），脚本会输出明确错误，此时才手动传 `--ali-id` / `--campaign-ids`。

### Step 1：计算日期范围

```python
from datetime import datetime, timedelta

end   = datetime.strptime(END_DATE, "%Y-%m-%d")
start = end - timedelta(days=PERIOD - 1)       # 当期开始
p_end   = start - timedelta(days=1)             # 上期结束
p_start = p_end - timedelta(days=PERIOD - 1)   # 上期开始

BEGIN_DT      = start.strftime("%Y-%m-%d 00:00:00")
END_DT        = end.strftime("%Y-%m-%d 23:59:59")
PREV_BEGIN_DT = p_start.strftime("%Y-%m-%d 00:00:00")
PREV_END_DT   = p_end.strftime("%Y-%m-%d 23:59:59")
STAT_DATE     = end.strftime("%Y-%m-%d")        # 图片快照日
```

### Step 2：并行数据采集（全自动，无需传 aliId / campaignIds）

```bash
SKILL_DIR="C:/Users/Jacken/.accio/accounts/1751506088/agents/DID-D464A3-85D464A3U1776211-6029-37B1DD/agent-core/skills/alibaba-p4p-report"
OUT_DIR="project/tmp_p4p_SHOPNAME_PERIODd"

python "${SKILL_DIR}/scripts/collect.py" \
  --begin "BEGIN_DT" \
  --end "END_DT" \
  --prev-begin "PREV_BEGIN_DT" \
  --prev-end "PREV_END_DT" \
  --stat-date "STAT_DATE" \
  --out-dir "${OUT_DIR}"
```

- **不传 `--ali-id` 和 `--campaign-ids`** → Phase 0 自动发现
- 采集完成后 `{OUT_DIR}/meta.json` 包含：`ali_id / campaign_ids / campaign_names / shop_name`
- 若某 datasource 失败，对应 Part 显示"暂无数据"，其余 Part 不受影响

### Step 3：生成 HTML 报告（自动从 meta.json 读取店铺名和计划ID）

```bash
python "${SKILL_DIR}/scripts/generate.py" \
  --data-dir "${OUT_DIR}" \
  --period PERIOD \
  --output "project/SHOP_NAME_直通车优化执行表_PERIODd_END_DATE.html"
```

- **不传 `--shop-name / --begin / --end / --campaign-ids`** → 自动从 `meta.json` 读取
- 输出文件名中的 `SHOP_NAME` 用 meta.json 里的 `shop_name` 替换

### Step 4：交付

1. 告知用户报告路径
2. 若用户有指定交付目录（如 `E:\Accio Work单独资料库\...`），使用 Python `shutil.copy2` 同步
3. 简述报告数据概况（各 Part 数据量、有无异常）

---

## 报告结构（6 Parts）

| Part | 内容 | 数据源 |
|------|------|--------|
| 1 | 账户整体 KPI + 计划对比（含环比） | `company_whole_site` × 2期 + `campaign_whole_site` × 2期 |
| 2 | 商品分级考核 Kill/Keep/Optimize（含缩略图） | `product_whole_site` + `data_advisor_shop_product`（图片） |
| 3 | 国家/地域淘汰建议 | `region_whole_site` |
| 4 | 买家搜索词分析（每计划 Top 15，Gap = 点击占比 - 曝光占比） | `searchword_whole_site`（每计划单独load） |
| 5 | 24时段分布 + 日度趋势（来自同一 `hour_whole_site`） | `hour_whole_site` |
| 6 | 标签定向画像（`target_tag_whole_site`，如未开放则显示地域替代） | `target_tag_whole_site` |

---

## 关键字段名（searchword_whole_site）

```
买家搜索词         → 搜索词文本
CLICKCNTRATIO      → 点击占比（%，已含百分号，直接用）
IMPRESSIONCNTRATIO → 曝光占比（%，已含百分号，直接用）
```
⚠️ 不要用 `搜索词`、`点击量`、`曝光量`，这些列在 searchword 表中不存在。

## 关键字段名（product_whole_site）

```
产品ID           → 商品ID
商品信息         → 商品名称
点击量 / 曝光量 / 全站商机量 / 全站商机转化率 / 点击率 / L1+买家点击占比
```

## 关键字段名（hour_whole_site）

```
时间  → "HH:MM" 格式，取 split(':')[0] 得小时
日期  → "YYYY-MM-DD"
点击量 / 全站商机量 / 花费
```

## 图片字段（data_advisor_shop_product）

```python
pid       = item.get('id', '')           # 商品ID
thumbnail = item.get('prodImage', '')    # 已是100×100，直接用，不拼接
name      = item.get('prodName', '') or item.get('subject', '')
```

---

## SQL 返回列头规则

`icbu_ads_report_execute_sql` 返回的列头**全部大写**：

```
COST / CLICKS / IMPRESSIONS / OPPORTUNITIES
```

读取时同时兼容大小写：
```python
cost = float(row.get('COST', row.get('cost', row.get('花费', 0))) or 0)
```

---

## 常见错误处理

| 现象 | 原因 | 解决 |
|------|------|------|
| `hourly` 返回500 | 该名称不存在 | 用 `hour_whole_site` |
| `tag` / `audience` 返回500 | 该名称不存在 | 用 `target_tag_whole_site` |
| Part 4 关键词全空 | 用了 `keyword` datasource | 改用 `searchword_whole_site` |
| 30天数据只返回1行 | `product`/`campaign` 在30天范围下只聚合整体 | 时段数据从 `hour_whole_site` 取（它有逐日逐时数据） |
| 图片空白 | 用了 `imageUrl` 字段 | 改用 `prodImage`（已含 `_100x100`） |
| `filters` 参数缺失 | searchword 必须带 campaignId filter | `"filters":{"campaignId":"ID"}` |
