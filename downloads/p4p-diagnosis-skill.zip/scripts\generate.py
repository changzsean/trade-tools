#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿里国际站 P4P 报告 — HTML 渲染器
支持从 meta.json 自动读取 shop-name / campaign-ids / begin / end，
只需传 --data-dir / --period / --output 即可。

用法（最简，配合 collect.py 自动发现后使用）:
  python generate.py \
    --data-dir /tmp/p4p_collect \
    --period 30 \
    --output ./report.html

用法（完整手动）:
  python generate.py \
    --data-dir /tmp/p4p_collect \
    --shop-name "MyShop" \
    --period 30 \
    --begin "2026-04-14" \
    --end "2026-05-13" \
    --campaign-ids "111111,222222" \
    --output ./MyShop_直通车优化执行表_30d.html
"""

import argparse, json, os, sys, io
from datetime import datetime

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")


def load_meta(data_dir: str) -> dict:
    """读取 collect.py 生成的 meta.json，返回元信息字典"""
    meta_path = os.path.join(data_dir, "meta.json")
    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


# ─────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────

def safe_float(v, default=0.0):
    try:
        return float(v)
    except Exception:
        return default


def safe_int(v, default=0):
    try:
        return int(float(v))
    except Exception:
        return default


def parse_tsv(filepath: str) -> list[dict]:
    """读取 sql_*.json，解析 TSV 数据，返回 [{col:val,...},...]"""
    if not os.path.exists(filepath):
        return []
    with open(filepath, "r", encoding="utf-8") as f:
        raw = json.load(f)
    data = raw.get("data", [])
    if not data or not isinstance(data, list):
        return []
    tsv = data[0].get("tsv_data", "")
    if not tsv:
        return []
    lines = tsv.strip().split("\n")
    if len(lines) < 2:
        return []
    headers = lines[0].split("\t")
    rows = []
    for line in lines[1:]:
        vals = line.split("\t")
        if len(vals) >= len(headers):
            rows.append(dict(zip(headers, vals)))
    return rows


def delta(cur_v, prev_v, lower_is_better=False):
    """返回 (delta_str, color)"""
    c, p = safe_float(cur_v), safe_float(prev_v)
    if p == 0:
        return "NEW", "#6366f1"
    pct = (c - p) / p * 100
    positive_good = not lower_is_better
    color = "#059669" if (pct >= 0) == positive_good else "#dc2626"
    sign = "+" if pct >= 0 else ""
    return f"{sign}{pct:.0f}%", color


# ─────────────────────────────────────────────
# CSS
# ─────────────────────────────────────────────

CSS = """
:root {
  --bg:#f9fafb; --card-bg:#ffffff; --text:#1a1a2e; --text2:#6b7280;
  --border:#e5e7eb; --blue:#2563eb; --green:#059669; --red:#dc2626;
  --yellow:#d97706; --tbl-hdr:#334155; --tbl-hdr-txt:#f1f5f9;
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;
  background:var(--bg);color:var(--text);line-height:1.6;padding:20px}
h1{font-size:22px;font-weight:700;color:#1e293b;margin-bottom:4px}
h2{font-size:18px;font-weight:700;color:#1e293b;margin:24px 0 12px;
  padding-bottom:8px;border-bottom:2px solid var(--border)}
h3{font-size:15px;font-weight:600;margin-bottom:8px}
.subtitle{font-size:13px;color:var(--text2);margin-bottom:20px}
.card{background:var(--card-bg);border-radius:10px;padding:16px;
  border:1px solid var(--border);margin-bottom:12px;
  box-shadow:0 1px 3px rgba(0,0,0,.04)}
.note{font-size:12px;color:var(--text2);margin:-6px 0 10px}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.kpi{background:var(--card-bg);border:1px solid var(--border);
  border-radius:8px;padding:14px;text-align:center}
.kpi-label{font-size:12px;color:var(--text2);margin-bottom:4px}
.kpi-value{font-size:22px;font-weight:700;color:#1e293b}
.kpi-delta{font-size:12px;margin-top:4px}
table{width:100%;border-collapse:collapse;font-size:13px}
thead th{background:var(--tbl-hdr);color:var(--tbl-hdr-txt);
  padding:8px 10px;text-align:left;font-weight:600;font-size:12px;
  white-space:nowrap}
tbody td{padding:6px 10px;border-bottom:1px solid #f1f5f9}
tbody tr:hover{background:#f8fafc}
.tag{display:inline-block;padding:2px 8px;border-radius:4px;
  font-size:11px;font-weight:700}
.tag-kill{background:var(--red);color:#fff}
.tag-keep{background:var(--yellow);color:#fff}
.tag-opt{background:var(--green);color:#fff}
.row-kill{background:#fef2f2!important}
.row-opt{background:#f0fdf4!important}
.insight{background:#f0f9ff;border-left:4px solid var(--blue);
  padding:12px 16px;border-radius:0 8px 8px 0;
  margin:12px 0;font-size:13px;line-height:1.8}
.flex-between{display:flex;justify-content:space-between}
@media(max-width:900px){.grid-2,.grid-4{grid-template-columns:1fr}}
"""


# ─────────────────────────────────────────────
# Part 1: 账户整体 + 计划对比
# ─────────────────────────────────────────────

def part1(company_cur, company_prev, campaign_cur, campaign_prev, period, begin, end):
    if not company_cur:
        return "<h2>Part 1 · 账户整体表现</h2><div class='card'><p>无账户数据</p></div>"
    c = company_cur[0]
    p = company_prev[0] if company_prev else {}

    def kpi(label, cur_key, prev_key=None, lower=False, fmt="int", prefix=""):
        val = safe_float(c.get(cur_key, 0))
        prev_val = safe_float(p.get(prev_key or cur_key, 0)) if p else 0
        d_str, d_color = delta(val, prev_val, lower_is_better=lower)
        if fmt == "cny":
            disp = f"¥{val:,.0f}"
        elif fmt == "pct":
            disp = f"{val:.2f}%"
        elif fmt == "float2":
            disp = f"{prefix}{val:.2f}"
        else:
            disp = f"{safe_int(val):,}"
        return f"""<div class="kpi">
  <div class="kpi-label">{label}</div>
  <div class="kpi-value">{disp}</div>
  <div class="kpi-delta" style="color:{d_color}">{d_str} vs 上期</div>
</div>"""

    row1 = (
        kpi("花费", "花费", fmt="cny", lower=True) +
        kpi("点击量", "点击量") +
        kpi("曝光量", "曝光量") +
        kpi("CTR", "点击率", fmt="pct")
    )
    row2 = (
        kpi("全站商机", "全站商机量") +
        kpi("商机转化率", "全站商机转化率", fmt="pct") +
        kpi("CPF", "全站商机成本", fmt="float2", prefix="¥", lower=True) +
        f"""<div class="kpi">
  <div class="kpi-label">询盘 / TM</div>
  <div class="kpi-value">{c.get('询盘量',0)} / {c.get('TM咨询量',0)}</div>
  <div class="kpi-delta">订单: {c.get('订单量',0)}</div>
</div>"""
    )

    # 计划对比表
    camp_rows = ""
    for row in campaign_cur:
        cid = row.get("计划ID", "")
        prev_row = next((r for r in campaign_prev if r.get("计划ID") == cid), {})
        opp_d, opp_c = delta(row.get("全站商机量", 0), prev_row.get("全站商机量", 0))
        camp_rows += f"""<tr>
<td>{row.get('计划名称','')}</td>
<td style="font-family:monospace;font-size:11px">{cid}</td>
<td>¥{safe_float(row.get('花费',0)):,.0f}</td>
<td>{row.get('点击量',0)}</td>
<td>{safe_int(row.get('曝光量',0)):,}</td>
<td>{safe_float(row.get('点击率',0)):.2f}%</td>
<td>{row.get('全站商机量',0)}</td>
<td style="color:{opp_c}">{opp_d}</td>
<td>{safe_float(row.get('全站商机转化率',0)):.2f}%</td>
<td>¥{safe_float(row.get('全站商机成本',0)):.2f}</td>
<td>{row.get('L1+全站商机量',0)}</td>
</tr>"""

    return f"""<h2>Part 1 · 账户整体表现</h2>
<div class="note">数据周期：{begin} ~ {end}（{period}天）· 环比：等长上期</div>
<div class="grid-4">{row1}</div>
<div class="grid-4" style="margin-top:12px">{row2}</div>
<div class="card" style="margin-top:16px">
<h3>计划维度对比</h3>
<table>
<thead><tr><th>计划名称</th><th>ID</th><th>花费</th><th>点击</th>
<th>曝光</th><th>CTR</th><th>商机</th><th>商机环比</th>
<th>CVR</th><th>CPF</th><th>L1+</th></tr></thead>
<tbody>{camp_rows or '<tr><td colspan=11>无计划数据</td></tr>'}</tbody>
</table></div>"""


# ─────────────────────────────────────────────
# Part 2: 商品分级（按实际品类自动聚类）
# ─────────────────────────────────────────────

def _extract_category(name: str) -> str:
    """
    从商品名称中提取品类标签。
    策略：取第一个有意义的名词短语（2~4个词），用于分组。
    不依赖任何硬编码品类，完全基于实际数据。
    """
    import re
    name = name.strip()
    if not name:
        return "Other"
    # 去掉括号内内容、特殊符号
    name_clean = re.sub(r"[\(\[\{][^\)\]\}]*[\)\]\}]", "", name)
    name_clean = re.sub(r"[^\w\s\-]", " ", name_clean).strip()
    tokens = name_clean.split()
    if not tokens:
        return "Other"
    # 取前3个有意义token（长度>1）作为品类标签
    meaningful = [t for t in tokens if len(t) > 1]
    return " ".join(meaningful[:3]) if meaningful else tokens[0]


def _auto_group_products(products: list[dict]) -> dict[str, list[dict]]:
    """
    全自动品类聚类：
    1. 为每个商品提取品类标签
    2. 用 TF-IDF 式简单词频统计找出高频词（代表主要品类）
    3. 按高频词将商品归组，剩余归 "其他"
    最多产生 4 个分组（避免分散）
    """
    from collections import Counter
    import re

    if not products:
        return {}

    # Step1: 对每个商品，拆分名称为 token 列表
    def tokenize(name):
        name = re.sub(r"[\(\[\{][^\)\]\}]*[\)\]\}]", "", name)
        name = re.sub(r"[^\w\s]", " ", name)
        return [t.lower() for t in name.split() if len(t) > 2]

    # Step2: 统计全部 token 词频（排除过于通用的词）
    STOP = {"and","the","for","with","set","new","hot","top","best","sale",
            "high","low","mini","pro","led","usb","diy","oem","odm","ce","rohs"}
    all_tokens = []
    prod_tokens = []
    for p in products:
        toks = [t for t in tokenize(p["name"]) if t not in STOP]
        prod_tokens.append(toks)
        all_tokens.extend(toks)

    freq = Counter(all_tokens)
    # 取词频最高的词作为品类锚词（最多3个锚词→最多3个主类+1个"其他"）
    anchors = [w for w, _ in freq.most_common(6) if freq[w] >= 2][:3]

    if not anchors:
        # 词频不足，全部放一组
        return {"全部商品": products}

    # Step3: 按锚词分组（首个命中的锚词决定归属）
    groups: dict[str, list[dict]] = {a: [] for a in anchors}
    groups["其他"] = []
    for p, toks in zip(products, prod_tokens):
        placed = False
        for anchor in anchors:
            if anchor in toks:
                groups[anchor].append(p)
                placed = True
                break
        if not placed:
            groups["其他"].append(p)

    # 移除空组
    groups = {k: v for k, v in groups.items() if v}

    # 如果"其他"太多（超过总数60%），说明锚词没代表性，改为单一"全部商品"组
    total = len(products)
    others = len(groups.get("其他", []))
    if others / total > 0.6:
        return {"全部商品": products}

    return groups


def part2(product_cur, img_data, period, campaign_names=None):
    """
    campaign_names: 从 meta.json 读取的计划名列表，用于在标题中展示来源计划。
    商品分组完全基于实际抓取数据，无任何硬编码品类。
    """
    PALETTE = ["#059669", "#2563eb", "#d97706", "#7c3aed", "#dc2626"]

    products = []
    for row in product_cur:
        pid = str(row.get("产品ID", ""))
        name = row.get("商品信息", f"Product {pid}")
        clicks  = safe_int(row.get("点击量", 0))
        leads   = safe_int(row.get("全站商机量", 0))
        cvr     = safe_float(row.get("全站商机转化率", 0))
        l1p     = safe_float(row.get("L1+买家点击占比", 0))
        ctr     = safe_float(row.get("点击率", 0))
        imp     = safe_int(row.get("曝光量", 0))
        # 判定逻辑
        if leads == 0 and clicks >= 10:
            verdict = "Kill"
        elif leads >= 3 and cvr >= 4:
            verdict = "Optimize"
        elif leads >= 1:
            verdict = "Keep"
        else:
            verdict = "Keep"
        products.append(dict(id=pid, name=name, clicks=clicks, leads=leads,
                             cvr=cvr, l1p=l1p, ctr=ctr, imp=imp, verdict=verdict))

    if not products:
        return "<h2>Part 2 · 商品分级考核</h2><div class='card'><p>无商品数据</p></div>"

    products.sort(key=lambda x: x["clicks"], reverse=True)
    products = products[:50]  # 最多取 Top50

    # 自动聚类
    groups = _auto_group_products(products)

    def build_table(prods, title, color):
        t_clicks = t_leads = t_kill = 0
        rows_html = ""
        # 构建图片兜底池：按 ID 匹配不到时按索引用已有图片
        img_pool = list(img_data.values())
        pool_idx = 0
        for p in prods:
            pid = p["id"]
            img_info  = img_data.get(pid, {})
            img_url   = img_info.get("image", "")
            detail_url = img_info.get("url", "")
            disp_name = (img_info.get("name") or "")[:55]
            # 兜底：无精确匹配则从图池轮询取图
            if not img_url and img_pool:
                fallback = img_pool[pool_idx % len(img_pool)]
                img_url = fallback.get("image", "")
                detail_url = fallback.get("url", detail_url)
                pool_idx += 1
            if not detail_url:
                detail_url = f"https://www.alibaba.com/product-detail/_{pid}.html"
            if not disp_name:
                disp_name = p["name"][:55]
            v  = p["verdict"]
            rc = {"Kill": "row-kill", "Keep": "", "Optimize": "row-opt"}[v]
            tc = {"Kill": "tag-kill", "Keep": "tag-keep", "Optimize": "tag-opt"}[v]
            t_clicks += p["clicks"]
            t_leads  += p["leads"]
            if v == "Kill":
                t_kill += 1
            rows_html += f"""<tr class="{rc}">
<td style="padding:4px"><img src="{img_url}" alt="{pid}"
  style="width:48px;height:48px;object-fit:contain;border-radius:4px" loading="lazy"></td>
<td style="font-family:monospace;font-size:11px">{pid}</td>
<td><a href="{detail_url}" target="_blank"
  style="color:#2563eb;text-decoration:none;font-size:13px">{disp_name}</a></td>
<td>{p['clicks']}</td><td>{p['ctr']:.2f}</td>
<td>{p['leads']}</td><td>{p['cvr']:.2f}</td><td>{p['l1p']:.2f}</td>
<td><span class="tag {tc}">{v}</span></td>
</tr>"""
        return f"""<div class="card">
<h3 style="color:{color};margin-bottom:10px;text-transform:capitalize">{title}</h3>
<table>
<thead><tr><th style="width:54px">图片</th><th>商品ID</th><th>商品名称</th>
<th>点击</th><th>CTR%</th><th>商机</th><th>CVR%</th><th>L1+%</th><th>判定</th>
</tr></thead>
<tbody>{rows_html}</tbody></table>
<div class="flex-between" style="margin-top:8px;font-size:12px;color:var(--text2)">
<span>{len(prods)} 品 · 点击 {t_clicks} · 商机 {t_leads}</span>
<span style="color:var(--red)">Kill {t_kill} 品</span>
</div></div>"""

    # 按 2 列网格排布各分组
    tables_html = ""
    for idx, (grp_name, grp_prods) in enumerate(groups.items()):
        color = PALETTE[idx % len(PALETTE)]
        tables_html += build_table(grp_prods, grp_name, color)

    # 汇总统计
    total_kill  = sum(1 for p in products if p["verdict"] == "Kill")
    total_opt   = sum(1 for p in products if p["verdict"] == "Optimize")
    total_keep  = sum(1 for p in products if p["verdict"] == "Keep")
    total_clicks = sum(p["clicks"] for p in products)
    total_leads  = sum(p["leads"] for p in products)
    kill_items  = "、".join(
        f"{p['name'][:20]}（{p['clicks']}c·0商机）"
        for p in products if p["verdict"] == "Kill"
    ) or "暂无"

    camp_label = "·".join(campaign_names[:3]) if campaign_names else "全部计划"

    return f"""<h2>Part 2 · 商品分级考核
  <span class="tag tag-opt" style="margin-left:8px">Optimize</span>
  <span class="tag tag-keep">Keep</span>
  <span class="tag tag-kill">Kill</span></h2>
<div class="note">数据来源：product_whole_site {period}天聚合（Top 50 按点击降序）·
计划：{camp_label} · 品类分组由算法自动聚类，无硬编码</div>
<div class="grid-2">{tables_html}</div>
<div class="insight">
<strong>分级结论：</strong>
<span class="tag tag-opt">Optimize</span> {total_opt} 品 ·
<span class="tag tag-keep">Keep</span> {total_keep} 品 ·
<span class="tag tag-kill">Kill</span>
<strong style="color:var(--red)">{total_kill} 品（零商机高点击，建议暂停投放）</strong><br>
<strong>全量：</strong>{len(products)} 品 · 总点击 {total_clicks} · 总商机 {total_leads}<br>
<strong>Kill 清单：</strong>{kill_items}
</div>"""


# ─────────────────────────────────────────────
# Part 3: 地域
# ─────────────────────────────────────────────

def part3(region_cur, period):
    if not region_cur:
        return "<h2>Part 3 · 国家/地域淘汰</h2><div class='card'><p>无地域数据</p></div>"
    kill_list = []
    rows = ""
    for row in region_cur:
        country = row.get("国家/地域", "")
        clicks = safe_int(row.get("点击量", 0))
        leads = safe_int(row.get("全站商机量", 0))
        ctr = safe_float(row.get("点击率", 0))
        cvr = safe_float(row.get("全站商机转化率", 0))
        l1p = safe_float(row.get("L1+买家点击占比", 0))
        if leads == 0 and clicks >= 5:
            verdict, rc, tc = "Kill", "row-kill", "tag-kill"
            kill_list.append(f"{country}（{clicks}c·0商机）")
        elif cvr >= 5:
            verdict, rc, tc = "Optimize", "row-opt", "tag-opt"
        else:
            verdict, rc, tc = "Keep", "", "tag-keep"
        rows += f"""<tr class="{rc}">
<td>{country}</td><td>{clicks}</td><td>{ctr:.1f}</td>
<td>{leads}</td><td>{cvr:.1f}</td><td>{l1p:.1f}</td>
<td><span class="tag {tc}">{verdict}</span></td></tr>"""
    return f"""<h2>Part 3 · 国家/地域淘汰</h2>
<div class="note">数据来源：region_whole_site {period}天聚合（按点击降序）</div>
<div class="card"><table>
<thead><tr><th>国家/地域</th><th>点击</th><th>CTR%</th>
<th>商机</th><th>CVR%</th><th>L1+%</th><th>判定</th></tr></thead>
<tbody>{rows}</tbody></table></div>
<div class="insight"><strong>地域淘汰建议：</strong>
{'、'.join(kill_list) if kill_list else '暂无高点击零商机地域'}</div>"""


# ─────────────────────────────────────────────
# Part 4: 关键词
# ─────────────────────────────────────────────

def part4(keyword_data: list[tuple[str, list]]):
    """keyword_data = [(campaign_label, rows), ...]"""
    tables = ""
    colors = ["#2563eb", "#059669", "#d97706", "#7c3aed"]
    for i, (label, rows) in enumerate(keyword_data):
        color = colors[i % len(colors)]
        kw_rows = ""
        for row in rows[:15]:
            kw = row.get("买家搜索词", "")
            ccr = safe_float(row.get("CLICKCNTRATIO", row.get("clickCntRatio", 0)))
            icr = safe_float(row.get("IMPRESSIONCNTRATIO", row.get("impressionCntRatio", 0)))
            gap = ccr - icr
            kw_rows += f"""<tr><td>{kw}</td>
<td>{ccr:.1f}%</td><td>{icr:.1f}%</td>
<td style="color:{'#059669' if gap>0 else '#dc2626'}">
  {'+' if gap>0 else ''}{gap:.1f}%</td></tr>"""
        tables += f"""<div class="card">
<h3 style="color:{color}">{label}</h3>
<table><thead><tr>
<th>买家搜索词</th><th>点击占比</th><th>曝光占比</th><th>Gap</th>
</tr></thead>
<tbody>{kw_rows or '<tr><td colspan=4>无关键词数据</td></tr>'}</tbody>
</table></div>"""
    return f"""<h2>Part 4 · 关键词搜索词分析</h2>
<div class="note">Gap = 点击占比 - 曝光占比。正值 = 高转化词；负值 = 高曝光低点击，需优化标题/主图。
数据来源：searchword_whole_site（每计划单独采集）</div>
<div class="grid-2">{tables}</div>"""


# ─────────────────────────────────────────────
# Part 5: 时段 & 日度趋势
# ─────────────────────────────────────────────

def part5(hour_cur, period):
    hour_map = {}
    daily_map = {}
    for row in hour_cur:
        hour = row.get("时间", "")
        date = row.get("日期", "")
        clicks = safe_int(row.get("点击量", 0))
        leads = safe_int(row.get("全站商机量", 0))
        cost = safe_float(row.get("花费", 0))
        if hour:
            h = hour.split(":")[0] if ":" in hour else hour
            bucket = hour_map.setdefault(h, {"clicks": 0, "leads": 0, "cost": 0.0})
            bucket["clicks"] += clicks
            bucket["leads"] += leads
            bucket["cost"] += cost
        if date:
            bucket = daily_map.setdefault(date, {"clicks": 0, "leads": 0, "cost": 0.0})
            bucket["clicks"] += clicks
            bucket["leads"] += leads
            bucket["cost"] += cost

    h_rows = "".join(
        f"<tr><td>{h}:00</td><td>{d['clicks']}</td><td>{d['leads']}</td><td>¥{d['cost']:.0f}</td></tr>"
        for h, d in sorted(hour_map.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 99)
    ) or "<tr><td colspan=4>暂无时段数据</td></tr>"

    d_rows = "".join(
        f"<tr><td>{dt}</td><td>{v['clicks']}</td><td>{v['leads']}</td><td>¥{v['cost']:.0f}</td></tr>"
        for dt, v in sorted(daily_map.items())
    ) or "<tr><td colspan=4>暂无日度数据</td></tr>"

    return f"""<h2>Part 5 · 分时段 & 日度趋势</h2>
<div class="note">数据来源：hour_whole_site {period}天合计（granularity=day）</div>
<div class="grid-2">
<div class="card">
<h3>24 时段分布（{period}天合计）</h3>
<table><thead><tr><th>时段</th><th>点击</th><th>商机</th><th>花费</th></tr></thead>
<tbody>{h_rows}</tbody></table></div>
<div class="card">
<h3>日度趋势</h3>
<table><thead><tr><th>日期</th><th>点击</th><th>商机</th><th>花费</th></tr></thead>
<tbody>{d_rows}</tbody></table></div>
</div>"""


# ─────────────────────────────────────────────
# Part 6: 标签
# ─────────────────────────────────────────────

def part6(tag_cur):
    if not tag_cur:
        return """<h2>Part 6 · 标签流量分析</h2>
<div class="card"><p style="color:var(--text2)">
target_tag_whole_site 暂无数据（功能可能未开放）</p></div>"""
    rows = "".join(
        f"""<tr><td>{r.get('标签名称','')}</td>
<td>{r.get('标签类型','')}</td>
<td>{r.get('国家','')}</td>
<td>{safe_float(r.get('FICLICKCNTRATIO',0)):.1f}%</td>
<td>{safe_float(r.get('IMPRESSIONCNTRATIO',0)):.1f}%</td></tr>"""
        for r in tag_cur
    )
    return f"""<h2>Part 6 · 标签流量分析</h2>
<div class="note">数据来源：target_tag_whole_site</div>
<div class="card"><table>
<thead><tr><th>标签名称</th><th>类型</th><th>国家</th>
<th>点击占比</th><th>曝光占比</th></tr></thead>
<tbody>{rows}</tbody></table></div>"""


# ─────────────────────────────────────────────
# Part 7: 标准推广（P4P直通车）
# ─────────────────────────────────────────────

def part7(std_company_cur, std_company_prev, std_campaign_cur,
          std_product_cur, std_keyword_cur, period):
    """标准推广（直通车 keyword datasource）完整分析"""

    no_data = (not std_company_cur and not std_campaign_cur
               and not std_product_cur and not std_keyword_cur)
    if no_data:
        return """<h2>Part 7 · 标准推广（直通车）</h2>
<div class="card"><p style="color:var(--text2)">
标准推广数据暂无（datasource=company/campaign/product/keyword 未返回数据）</p></div>"""

    # ── 账户 KPI 对比（全站推广 vs 标准推广）──
    def kpi_row(label, ws_val, std_val, lower=False, fmt="int", prefix=""):
        def fmt_val(v):
            v = safe_float(v)
            if fmt == "cny":   return f"¥{v:,.0f}"
            if fmt == "pct":   return f"{v:.2f}%"
            if fmt == "f2":    return f"{prefix}{v:.2f}"
            return f"{safe_int(v):,}"
        ws  = fmt_val(ws_val)
        std = fmt_val(std_val)
        return f"<tr><td>{label}</td><td>{ws}</td><td>{std}</td></tr>"

    ws  = std_company_cur[0]  if std_company_cur  else {}  # 注意：这里实际是全站 company
    std = std_company_cur[0]  if std_company_cur  else {}

    # 账户对比表（全站数据在 Part1 已展示，这里只展示标准推广自身 KPI）
    std_c  = std_company_cur[0]  if std_company_cur  else {}
    std_cp = std_company_prev[0] if std_company_prev else {}

    def std_kpi(label, key, lower=False, fmt="int", prefix=""):
        cur_v  = safe_float(std_c.get(key, 0))
        prev_v = safe_float(std_cp.get(key, 0))
        d_str, d_color = delta(cur_v, prev_v, lower_is_better=lower)
        if fmt == "cny":  disp = f"¥{cur_v:,.0f}"
        elif fmt == "pct": disp = f"{cur_v:.2f}%"
        elif fmt == "f2":  disp = f"{prefix}{cur_v:.2f}"
        else:              disp = f"{safe_int(cur_v):,}"
        return f"""<div class="kpi">
<div class="kpi-label">{label}</div>
<div class="kpi-value">{disp}</div>
<div class="kpi-delta" style="color:{d_color}">{d_str} vs 上期</div>
</div>"""

    kpi_html = (
        std_kpi("花费", "花费", fmt="cny", lower=True) +
        std_kpi("点击量", "点击量") +
        std_kpi("曝光量", "曝光量") +
        std_kpi("CTR", "点击率", fmt="pct")
    )

    # ── 计划维度 ──
    camp_rows = ""
    for row in std_campaign_cur:
        camp_rows += f"""<tr>
<td>{row.get('计划名称','')}</td>
<td style="font-family:monospace;font-size:11px">{row.get('计划ID','')}</td>
<td>¥{safe_float(row.get('花费',0)):,.0f}</td>
<td>{row.get('点击量',0)}</td>
<td>{safe_int(row.get('曝光量',0)):,}</td>
<td>{safe_float(row.get('点击率',0)):.2f}%</td>
<td>{row.get('询盘量',0)}</td>
<td>{row.get('订单量',0)}</td>
</tr>"""

    # ── 商品维度（Kill/Keep/Opt） ──
    prod_rows = ""
    for row in std_product_cur[:20]:
        pid    = str(row.get("产品ID", ""))
        name   = row.get("商品信息", f"Product {pid}")[:50]
        clicks = safe_int(row.get("点击量", 0))
        leads  = safe_int(row.get("询盘量", row.get("全站商机量", 0)))
        ctr    = safe_float(row.get("点击率", 0))
        cost   = safe_float(row.get("花费", 0))
        if leads == 0 and clicks >= 5:
            v, rc, tc = "Kill", "row-kill", "tag-kill"
        elif leads >= 2:
            v, rc, tc = "Optimize", "row-opt", "tag-opt"
        else:
            v, rc, tc = "Keep", "", "tag-keep"
        prod_rows += f"""<tr class="{rc}">
<td style="font-family:monospace;font-size:11px">{pid}</td>
<td><a href="https://www.alibaba.com/product-detail/_{pid}.html" target="_blank"
  style="color:#2563eb;font-size:12px">{name}</a></td>
<td>{clicks}</td><td>{ctr:.2f}%</td>
<td>¥{cost:.0f}</td><td>{leads}</td>
<td><span class="tag {tc}">{v}</span></td>
</tr>"""

    # ── 关键词维度 ──
    kw_rows = ""
    for row in std_keyword_cur[:20]:
        kw     = row.get("关键词", row.get("keyword", ""))
        clicks = row.get("点击量", 0)
        imp    = safe_int(row.get("曝光量", 0))
        ctr    = safe_float(row.get("点击率", 0))
        cost   = safe_float(row.get("花费", 0))
        avg_pos = safe_float(row.get("平均排名", row.get("avgPosition", 0)))
        leads  = row.get("询盘量", 0)
        cpc    = safe_float(row.get("平均点击价格", row.get("avgCpc", 0)))
        kw_rows += f"""<tr>
<td>{kw}</td><td>{clicks}</td><td>{imp:,}</td>
<td>{ctr:.2f}%</td><td>¥{cost:.2f}</td>
<td>{avg_pos:.1f}</td><td>{leads}</td><td>¥{cpc:.2f}</td>
</tr>"""

    return f"""<h2>Part 7 · 标准推广（直通车 P4P）</h2>
<div class="note">数据来源：datasource=company/campaign/product/keyword（标准推广专属，{period}天）</div>

<h3 style="margin:12px 0 8px">账户整体 KPI</h3>
<div class="grid-4">{kpi_html}</div>

<div class="grid-2" style="margin-top:16px">
  <div class="card">
    <h3>计划维度</h3>
    <table><thead><tr>
    <th>计划名称</th><th>ID</th><th>花费</th><th>点击</th>
    <th>曝光</th><th>CTR%</th><th>询盘</th><th>订单</th>
    </tr></thead>
    <tbody>{camp_rows or '<tr><td colspan=8>无计划数据</td></tr>'}</tbody>
    </table>
  </div>
  <div class="card">
    <h3>关键词 Top 20</h3>
    <table><thead><tr>
    <th>关键词</th><th>点击</th><th>曝光</th><th>CTR%</th>
    <th>花费</th><th>均排</th><th>询盘</th><th>CPC</th>
    </tr></thead>
    <tbody>{kw_rows or '<tr><td colspan=8>无关键词数据</td></tr>'}</tbody>
    </table>
  </div>
</div>

<div class="card" style="margin-top:12px">
  <h3>商品维度考核（标准推广·Top 20）</h3>
  <table><thead><tr>
  <th>商品ID</th><th>商品名称</th><th>点击</th><th>CTR%</th>
  <th>花费</th><th>询盘</th><th>判定</th>
  </tr></thead>
  <tbody>{prod_rows or '<tr><td colspan=7>无商品数据</td></tr>'}</tbody>
  </table>
</div>"""


# ─────────────────────────────────────────────
# 主渲染
# ─────────────────────────────────────────────

def generate(args):
    d = args.data_dir
    campaign_ids = [c.strip() for c in args.campaign_ids.split(",") if c.strip()]

    # 从 meta.json 获取计划名（供 Part2 展示）
    meta = load_meta(d)
    campaign_names = meta.get("campaign_names", [])

    # 加载所有 TSV —— 全站推广
    company_cur   = parse_tsv(os.path.join(d, "sql_company_cur.json"))
    company_prev  = parse_tsv(os.path.join(d, "sql_company_prev.json"))
    campaign_cur  = parse_tsv(os.path.join(d, "sql_campaign_cur.json"))
    campaign_prev = parse_tsv(os.path.join(d, "sql_campaign_prev.json"))
    product_cur   = parse_tsv(os.path.join(d, "sql_product_cur.json"))
    region_cur    = parse_tsv(os.path.join(d, "sql_region_cur.json"))
    hour_cur      = parse_tsv(os.path.join(d, "sql_hour_cur.json"))
    tag_cur       = parse_tsv(os.path.join(d, "sql_tag_cur.json"))

    # 加载所有 TSV —— 标准推广（P4P直通车）
    std_company_cur  = parse_tsv(os.path.join(d, "sql_std_company_cur.json"))
    std_company_prev = parse_tsv(os.path.join(d, "sql_std_company_prev.json"))
    std_campaign_cur = parse_tsv(os.path.join(d, "sql_std_campaign_cur.json"))
    std_product_cur  = parse_tsv(os.path.join(d, "sql_std_product_cur.json"))
    std_keyword_cur  = parse_tsv(os.path.join(d, "sql_std_keyword_cur.json"))

    # 图片索引（id → {image, url, name}）
    img_data = {}
    img_file = os.path.join(d, "load_images.json")
    if os.path.exists(img_file):
        with open(img_file, "r", encoding="utf-8") as f:
            raw = json.load(f)
        img_list = raw.get("data_parsed", raw.get("data", {}))
        if isinstance(img_list, str):
            try:
                img_list = json.loads(img_list)
            except Exception:
                img_list = {}
        if isinstance(img_list, dict):
            img_list = img_list.get("data", [])
        for item in (img_list or []):
            pid = str(item.get("id", ""))
            # prodImage 已经是 100×100，直接用，无需拼接
            img_data[pid] = {
                "image": item.get("prodImage", ""),
                "url": item.get("detailUrl", f"https://www.alibaba.com/product-detail/_{pid}.html"),
                "name": item.get("prodName", "") or item.get("subject", f"Product {pid}"),
            }

    # 关键词数据（每计划一份）
    keyword_data = []
    for i, cid in enumerate(campaign_ids, start=1):
        rows = parse_tsv(os.path.join(d, f"sql_keyword_{i}.json"))
        # 从计划汇总找计划名
        label_name = cid
        for row in campaign_cur:
            if str(row.get("计划ID", "")) == cid:
                label_name = f"{row.get('计划名称', cid)}"
                break
        keyword_data.append((f"计划 {label_name}（{cid}）", rows))

    # 渲染各 Part
    p1 = part1(company_cur, company_prev, campaign_cur, campaign_prev,
               args.period, args.begin, args.end)
    p2 = part2(product_cur, img_data, args.period, campaign_names)
    p3 = part3(region_cur, args.period)
    p4 = part4(keyword_data)
    p5 = part5(hour_cur, args.period)
    p6 = part6(tag_cur)
    p7 = part7(std_company_cur, std_company_prev, std_campaign_cur,
               std_product_cur, std_keyword_cur, args.period)

    gen_time = datetime.now().strftime("%Y-%m-%d %H:%M")
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{args.shop_name} · 直通车优化执行表 · {args.period}天 · {args.end}</title>
<style>{CSS}</style>
</head>
<body>
<h1>全站推广优化执行表</h1>
<div class="subtitle">
  {args.shop_name} · {args.period}天 ·
  {args.begin} ~ {args.end} · 生成时间 {gen_time}
</div>

{p1}
{p2}
{p3}
{p4}
{p5}
{p6}
{p7}

<div class="insight" style="margin-top:24px">
<strong>报告说明：</strong>
全站推广采集：company×2 + campaign×2 + product + region + hour + tag + searchword×{len(campaign_ids)} + 图片<br>
标准推广采集：company×2 + campaign + product + keyword（datasource 不带 _whole_site 后缀）<br>
商品分组：算法自动聚类（TF-IDF词频），无硬编码品类 · 图片来源：data_advisor_shop_product·prodImage字段<br>
</div>
</body>
</html>"""

    out = args.output
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"✅ 报告已生成: {out}")
    print(f"   文件大小: {len(html):,} 字符")
    return out


def main():
    parser = argparse.ArgumentParser(description="P4P 报告 HTML 渲染器（支持从 meta.json 自动读取参数）")
    parser.add_argument("--data-dir",     required=True,  help="collect.py 的输出目录（含 meta.json）")
    parser.add_argument("--period",       required=True,  type=int, help="周期天数（7 或 30）")
    parser.add_argument("--output",       required=True,  help="输出 HTML 路径")
    # 以下参数可选，缺省时从 meta.json 自动读取
    parser.add_argument("--shop-name",    default="",  help="店铺名（留空从 meta.json 读取）")
    parser.add_argument("--begin",        default="",  help="当期开始 YYYY-MM-DD（留空从 meta.json 读取）")
    parser.add_argument("--end",          default="",  help="当期结束 YYYY-MM-DD（留空从 meta.json 读取）")
    parser.add_argument("--campaign-ids", default="",  help="计划ID逗号分隔（留空从 meta.json 读取）")
    args = parser.parse_args()

    # 从 meta.json 补全缺省值
    meta = load_meta(args.data_dir)
    if not args.shop_name:
        args.shop_name = meta.get("shop_name", "MyShop")
    if not args.begin:
        # meta 里存的是 "YYYY-MM-DD HH:MM:SS"，取前10位
        args.begin = meta.get("begin", "")[:10]
    if not args.end:
        args.end = meta.get("end", "")[:10]
    if not args.campaign_ids:
        ids = meta.get("campaign_ids", [])
        args.campaign_ids = ",".join(str(i) for i in ids)

    # 验证必要字段
    missing = [k for k, v in [("--begin", args.begin), ("--end", args.end),
                               ("--campaign-ids", args.campaign_ids)] if not v]
    if missing:
        parser.error(f"缺少必要参数，且 meta.json 中也未找到: {missing}\n"
                     f"请手动传入，或确认 --data-dir 下存在 meta.json")

    print(f"[generate] 店铺: {args.shop_name} | 周期: {args.period}天 | {args.begin}~{args.end}")
    generate(args)


if __name__ == "__main__":
    main()
