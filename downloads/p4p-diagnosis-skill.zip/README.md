# alibaba-p4p-report — 字段名踩坑手册

> 本文档记录在开发过程中踩过的所有坑，**每次修改前必读**。

---

## 1. Datasource 名称对照表（最重要）

| 数据维度 | ✅ 正确名称 | ❌ 错误名称（用这些会500或返回空） |
|---------|-----------|-------------------------------|
| 账户整体 | `company_whole_site` | `company` |
| 计划维度 | `campaign_whole_site` | `campaign` |
| 商品维度 | `product_whole_site` | `product` |
| 地域维度 | `region_whole_site` | `region` |
| 关键词搜索词 | `searchword_whole_site` | `keyword`（根本不存在）|
| 时段分布 | `hour_whole_site` | `hourly`（500错误）|
| 标签定向 | `target_tag_whole_site` | `tag`（500）`audience`（500）|

**规律：全站推广所有 datasource 名称必须带 `_whole_site` 后缀。**

---

## 2. searchword_whole_site 必须带 filters

```python
# 正确
{
    "datasource": "searchword_whole_site",
    "filters": {"campaignId": "379192402"},  # ← 必须
    "tempTableName": "SW_CAMP1"
}

# 错误（返回空或报错）
{
    "datasource": "searchword_whole_site"
    # 缺少 filters
}
```

每个计划需要**单独调用**一次 load。

---

## 3. SQL 列名大小写

`icbu_ads_report_execute_sql` 返回的列名**完全大写**：

```
COST          CLICKS        IMPRESSIONS   OPPORTUNITIES
CLICKCNTRATIO             IMPRESSIONCNTRATIO
FICLICKCNTRATIO
```

解析时要同时兼容原始中文列名（`花费`）和大写英文列名（`COST`）：

```python
cost = float(row.get('花费', row.get('COST', row.get('cost', 0))) or 0)
```

实测：中文列名 `花费` / `点击量` / `曝光量` / `全站商机量` 在返回的 TSV 里依然是中文。
只有类似 `CLICKCNTRATIO` 这种占比指标是纯大写英文。

---

## 4. 商品图片字段

```python
# data_advisor_shop_product 接口返回字段：
pid       = item.get('id', '')           # 商品ID（字符串）
thumbnail = item.get('prodImage', '')    # ✅ 已是 100×100，直接用
name      = item.get('prodName', '') or item.get('subject', '')

# 错误字段（不存在）：
item.get('imageUrl')    # ← 不存在
item.get('image')       # ← 不存在
item.get('imgUrl')      # ← 不存在
```

图片 URL 格式例：`https://sc04.alicdn.com/kf/xxx.jpg_100x100.jpg`
**不需要拼接 `_100x100`**，接口已经返回带尺寸后缀的 URL。

---

## 5. icbu_ads_report_load_datasource 必须含 tempTableName

```python
# 正确
{
    "datasource": "hour_whole_site",
    "beginDateTime": "2026-04-14 00:00:00",
    "endDateTime": "2026-05-13 23:59:59",
    "granularity": "day",
    "tempTableName": "HOUR"   # ← 必须，否则后续 SQL 无法引用
}
```

不同 load 之间的 tempTableName 不能重复（同一 session 内全局有效）。
建议命名：`CUR_COMPANY` / `PREV_COMPANY` / `CUR_CAMP` / `PREV_CAMP` / `PROD` / `REGION` / `HOUR` / `TAG` / `SW_CAMP1` / `SW_CAMP2`

---

## 6. hour_whole_site 数据结构

SQL 结果的列名：
```
时间    → "14:00" 格式
日期    → "2026-05-10" 格式
点击量  → 该时段点击数（整数）
全站商机量 → 商机数
花费    → ¥ 浮点数
```

提取小时桶：
```python
h = row.get('时间', '').split(':')[0]  # "14"
```

---

## 7. 日期范围计算

```python
from datetime import datetime, timedelta

end   = datetime.strptime(END_DATE, "%Y-%m-%d")
start = end - timedelta(days=PERIOD - 1)       # 当期首日
p_end   = start - timedelta(days=1)            # 上期末
p_start = p_end - timedelta(days=PERIOD - 1)  # 上期首

# API 参数格式（含时分秒）
BEGIN_DT = start.strftime("%Y-%m-%d 00:00:00")
END_DT   = end.strftime("%Y-%m-%d 23:59:59")
```

---

## 8. 调用方式（accio-mcp-cli）

```bash
# Windows + Git Bash
accio-mcp-cli call icbu_ads_report_load_datasource --json '{"datasource":"hour_whole_site",...}'

# 注意：JSON 内不能有单引号，必须全用双引号
# 在 Python subprocess 中：
escaped = json.dumps(args_dict, ensure_ascii=False).replace('"', '\\"')
cmd = f'"{MCP_CLI}" call {tool} --json "{escaped}"'
```

---

## 9. 文件命名约定

| 文件类型 | 命名格式 |
|---------|---------|
| load 原始 | `load_company_cur.json` / `load_hour_cur.json` / `load_keyword_1.json` |
| SQL 结果 | `sql_company_cur.json` / `sql_keyword_2.json` |
| 图片数据 | `load_images.json` |
| 最终报告 | `{SHOP_NAME}_直通车优化执行表_{PERIOD}d_{END_DATE}.html` |

---

## 10. 报告 6 Part 结构

| Part | 标题 | 数据源文件 |
|------|------|----------|
| 1 | 账户整体 + 计划环比 | `sql_company_cur/prev.json` + `sql_campaign_cur/prev.json` |
| 2 | 商品分级（Kill/Keep/Opt + 缩略图） | `sql_product_cur.json` + `load_images.json` |
| 3 | 国家/地域淘汰 | `sql_region_cur.json` |
| 4 | 买家搜索词分析 | `sql_keyword_1.json` / `sql_keyword_2.json` |
| 5 | 24时段 + 日度趋势 | `sql_hour_cur.json` |
| 6 | 标签定向画像 | `sql_tag_cur.json` |

---

## 11. 快速上手（完整示例）

```bash
# Step 1: 采集数据
python scripts/collect.py \
  --ali-id 240336452 \
  --begin "2026-04-14 00:00:00" \
  --end "2026-05-13 23:59:59" \
  --prev-begin "2026-03-15 00:00:00" \
  --prev-end "2026-04-13 23:59:59" \
  --campaign-ids "379192402,349774361" \
  --stat-date "2026-05-13" \
  --out-dir /tmp/p4p_lyl_30d

# Step 2: 生成报告
python scripts/generate.py \
  --data-dir /tmp/p4p_lyl_30d \
  --shop-name "Liangyueliang" \
  --period 30 \
  --begin "2026-04-14" \
  --end "2026-05-13" \
  --campaign-ids "379192402,349774361" \
  --output ./output/Liangyueliang_直通车优化执行表_30d_2026-05-13.html
```

---

## 版本历史

| 版本 | 日期 | 变更 |
|-----|------|------|
| v1.0 | 2026-05-13 | 从 generate_7d_report.py 改造，参数化封装 |
| — | 踩坑 | `hourly` / `tag` / `keyword` 均500，改用 `*_whole_site` 后缀 |
| — | 踩坑 | `prodImage` 非 `imageUrl`；searchword 必须含 campaignId filter |
