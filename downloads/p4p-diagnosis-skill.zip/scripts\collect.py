#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿里国际站 P4P 报告 — 并行数据采集器
支持全自动发现 aliId 和活跃计划ID，无需手动输入。

用法（全自动）:
  python collect.py \
    --begin "2026-04-14 00:00:00" \
    --end "2026-05-13 23:59:59" \
    --prev-begin "2026-03-15 00:00:00" \
    --prev-end "2026-04-13 23:59:59" \
    --stat-date "2026-05-13" \
    --out-dir /tmp/p4p_collect

用法（手动指定，覆盖自动发现）:
  python collect.py \
    --ali-id 123456 \
    --campaign-ids "111111,222222" \
    --begin "2026-04-14 00:00:00" \
    ...

Phase 0: 自动发现 aliId + 活跃计划ID（通过 icbu_ads_entity）
Phase 1: 并行 load 多个 datasource
Phase 2: 并行 execute SQL
"""

import argparse, json, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed

MCP_CLI = "accio-mcp-cli"
TIMEOUT = 90


# ─────────────────────────────────────────────
# MCP 调用封装
# ─────────────────────────────────────────────

def mcp_call(tool: str, args: dict) -> dict:
    args_json = json.dumps(args, ensure_ascii=False)
    escaped = args_json.replace('"', '\\"')
    cmd = f'"{MCP_CLI}" call {tool} --json "{escaped}"'
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=TIMEOUT, encoding="utf-8")
        raw = r.stdout.strip()
        if not raw:
            return {"_err": f"empty stdout. stderr={r.stderr[:300]}"}
        return json.loads(raw)
    except subprocess.TimeoutExpired:
        return {"_err": "timeout"}
    except json.JSONDecodeError as e:
        return {"_err": f"json parse: {e}  raw={r.stdout[:200]}"}
    except Exception as e:
        return {"_err": str(e)}


def save(path: str, data: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ─────────────────────────────────────────────
# Phase 0: 自动发现 aliId + 活跃计划ID
# ─────────────────────────────────────────────

def auto_discover(out_dir: str) -> tuple[str, list[str], list[str], str]:
    """
    自动发现当前账户的 aliId 和活跃计划ID列表。
    返回: (ali_id, campaign_ids, campaign_names, shop_name)

    策略:
    1. 调 icbu_ads_entity(entityType=campaign) 获取计划列表
       - onlineStatus=="1" 为投放中的活跃计划
       - 从 campaignId 列表中反推 aliId（取计划的 memberId 字段）
    2. 若计划接口没有 aliId，再调 icbu_company_info 或 member_info 获取
    """
    print("[Phase 0] 自动发现 aliId 和活跃计划...")

    # Step A: 拉取计划列表
    resp = mcp_call("icbu_ads_entity", {
        "entityType": "campaign",
        "filters": {},
        "pageIndex": 1,
        "pageSize": 100
    })
    save(os.path.join(out_dir, "discover_campaigns.json"), resp)

    if not resp.get("success"):
        raise RuntimeError(f"icbu_ads_entity 调用失败: {resp.get('_err', resp.get('errorMsg', '未知错误'))}")

    # 解析计划列表 —— 兼容多种返回结构
    data = resp.get("data", {})
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except Exception:
            data = {}

    # 兼容多种返回结构：detailList / result / campaigns / list / data（直接列表）
    raw_list = (
        data.get("detailList") or   # 实测结构（2026-05 验证）
        data.get("result") or
        data.get("campaigns") or
        data.get("list") or
        data.get("data") or
        (data if isinstance(data, list) else [])
    )
    if not raw_list:
        raise RuntimeError(f"icbu_ads_entity 返回的计划列表为空。原始 data keys: {list(data.keys()) if isinstance(data, dict) else type(data)}")

    # 筛选活跃计划（onlineStatus == "1" 或 status == "active"/"ONLINE"）
    active = []
    for item in raw_list:
        status = str(item.get("onlineStatus", item.get("status", ""))).strip()
        if status in ("1", "active", "ONLINE", "online"):
            active.append(item)

    if not active:
        # 降级：取所有计划（可能没有 status 字段）
        print("  [警告] 未找到 onlineStatus==1 的计划，使用全部计划")
        active = raw_list

    campaign_ids = [str(item.get("campaignId", item.get("id", ""))) for item in active]
    campaign_ids = [c for c in campaign_ids if c]
    campaign_names = [str(item.get("campaignName", item.get("name", f"计划{cid}")))
                      for item, cid in zip(active, campaign_ids)]

    print(f"  发现 {len(campaign_ids)} 个活跃计划: {campaign_ids}")

    # Step B: 自动获取 aliId
    ali_id = ""
    shop_name = "MyShop"

    # 方法1: 从计划数据中取 memberId / aliId / userId
    for item in active:
        for key in ("memberId", "aliId", "userId", "memberSeq"):
            v = str(item.get(key, "")).strip()
            if v and v.isdigit():
                ali_id = v
                break
        if ali_id:
            break

    # 方法2: 调 icbu_company_info
    if not ali_id:
        info_resp = mcp_call("icbu_company_info", {})
        save(os.path.join(out_dir, "discover_company.json"), info_resp)
        if info_resp.get("success"):
            info_data = info_resp.get("data", {})
            if isinstance(info_data, str):
                try:
                    info_data = json.loads(info_data)
                except Exception:
                    info_data = {}
            for key in ("aliId", "memberId", "userId", "memberSeq", "loginId"):
                v = str(info_data.get(key, "")).strip()
                if v and v.isdigit():
                    ali_id = v
                    break
            # 顺便取店铺名
            shop_name = (
                info_data.get("companyName") or
                info_data.get("shopName") or
                info_data.get("memberName") or
                shop_name
            )

    # 方法3: 调 member_info（部分账户可能走这个）
    if not ali_id:
        member_resp = mcp_call("member_info", {})
        save(os.path.join(out_dir, "discover_member.json"), member_resp)
        if member_resp.get("success"):
            m_data = member_resp.get("data", {})
            if isinstance(m_data, str):
                try:
                    m_data = json.loads(m_data)
                except Exception:
                    m_data = {}
            for key in ("aliId", "memberId", "userId", "memberSeq"):
                v = str(m_data.get(key, "")).strip()
                if v and v.isdigit():
                    ali_id = v
                    break
            if not shop_name or shop_name == "MyShop":
                shop_name = m_data.get("companyName") or m_data.get("shopName") or shop_name

    if not ali_id:
        raise RuntimeError(
            "无法自动获取 aliId。请手动传入 --ali-id 参数。\n"
            "参考：icbu_ads_entity / icbu_company_info / member_info 均未返回 aliId。\n"
            f"discover_company.json 和 discover_campaigns.json 已保存至 {out_dir}"
        )

    print(f"  aliId    : {ali_id}")
    print(f"  店铺名   : {shop_name}")
    return ali_id, campaign_ids, campaign_names, shop_name


# ─────────────────────────────────────────────
# Phase 1: Load datasources
# ─────────────────────────────────────────────

def phase1_load(args_ns, out_dir: str, campaign_ids: list[str]) -> dict[str, bool]:
    """并行 load 所有数据源，返回 {filename: success}"""

    tasks = [
        ("load_company_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "company_whole_site",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "CUR_COMPANY",
        }),
        ("load_company_prev.json", "icbu_ads_report_load_datasource", {
            "datasource": "company_whole_site",
            "beginDateTime": args_ns.prev_begin, "endDateTime": args_ns.prev_end,
            "tempTableName": "PREV_COMPANY",
        }),
        ("load_campaign_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "campaign_whole_site",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "CUR_CAMP",
        }),
        ("load_campaign_prev.json", "icbu_ads_report_load_datasource", {
            "datasource": "campaign_whole_site",
            "beginDateTime": args_ns.prev_begin, "endDateTime": args_ns.prev_end,
            "tempTableName": "PREV_CAMP",
        }),
        ("load_product_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "product_whole_site",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "PROD",
        }),
        ("load_region_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "region_whole_site",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "REGION",
        }),
        # 注意：时段必须用 hour_whole_site，不是 hourly
        ("load_hour_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "hour_whole_site",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "granularity": "day",
            "tempTableName": "HOUR",
        }),
        # 注意：标签必须用 target_tag_whole_site，不是 tag/audience
        ("load_tag_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "target_tag_whole_site",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "TAG",
        }),
        ("load_images.json", "data_advisor_shop_product", {
            "shopProductQueryParam": {
                "aliId": int(args_ns.ali_id),
                "statDate": args_ns.stat_date,
                "statisticsType": "day",
                "pageSize": 500,
                "pageNo": 1,
            }
        }),
    ]

    # 搜索词（全站）：每个计划单独 load（searchword_whole_site，不是 keyword）
    for i, cid in enumerate(campaign_ids, start=1):
        tasks.append((
            f"load_keyword_{i}.json",
            "icbu_ads_report_load_datasource",
            {
                "datasource": "searchword_whole_site",
                "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
                "filters": {"campaignId": cid},
                "tempTableName": f"SW_CAMP{i}",
            }
        ))

    # ── 标准推广（P4P）数据 ──────────────────────────────
    # 账户整体（标准推广）
    tasks += [
        ("load_std_company_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "company",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "STD_CUR_COMPANY",
        }),
        ("load_std_company_prev.json", "icbu_ads_report_load_datasource", {
            "datasource": "company",
            "beginDateTime": args_ns.prev_begin, "endDateTime": args_ns.prev_end,
            "tempTableName": "STD_PREV_COMPANY",
        }),
        # 计划（标准推广）
        ("load_std_campaign_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "campaign",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "STD_CUR_CAMP",
        }),
        # 商品（标准推广）
        ("load_std_product_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "product",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "STD_PROD",
        }),
        # 关键词（标准推广，datasource=keyword，注意：只对标准推广有效）
        ("load_std_keyword_cur.json", "icbu_ads_report_load_datasource", {
            "datasource": "keyword",
            "beginDateTime": args_ns.begin, "endDateTime": args_ns.end,
            "tempTableName": "STD_KW",
        }),
    ]

    results = {}

    def run_task(fname, tool, payload):
        path = os.path.join(out_dir, fname)
        data = mcp_call(tool, payload)
        save(path, data)
        ok = data.get("success") is True
        return fname, ok, data

    with ThreadPoolExecutor(max_workers=12) as pool:
        futures = [pool.submit(run_task, f, t, p) for f, t, p in tasks]
        for fut in as_completed(futures):
            fname, ok, data = fut.result()
            if ok:
                try:
                    rows = data["data"]["table_meta"].get("total_rows", "?")
                except Exception:
                    rows = "?"
                status = f"[OK] rows={rows}"
            else:
                status = f"[FAIL] {data.get('_err', data.get('errorMsg', '?'))}"
            print(f"  {status:<35} {fname}")
            results[fname] = ok

    return results


# ─────────────────────────────────────────────
# Phase 2: Execute SQL
# ─────────────────────────────────────────────

def phase2_sql(out_dir: str, p1_results: dict, campaign_ids: list[str]):
    sql_tasks = []

    def add(fname, load_fname, queries):
        if p1_results.get(load_fname):
            sql_tasks.append((fname, queries))

    add("sql_company_cur.json",   "load_company_cur.json",   ["SELECT * FROM CUR_COMPANY"])
    add("sql_company_prev.json",  "load_company_prev.json",  ["SELECT * FROM PREV_COMPANY"])
    add("sql_campaign_cur.json",  "load_campaign_cur.json",  ["SELECT * FROM CUR_CAMP LIMIT 50"])
    add("sql_campaign_prev.json", "load_campaign_prev.json", ["SELECT * FROM PREV_CAMP LIMIT 50"])
    add("sql_product_cur.json",   "load_product_cur.json",   ["SELECT * FROM PROD LIMIT 100"])
    add("sql_region_cur.json",    "load_region_cur.json",    ["SELECT * FROM REGION LIMIT 30"])
    add("sql_hour_cur.json",      "load_hour_cur.json",      ["SELECT * FROM HOUR LIMIT 1000"])
    add("sql_tag_cur.json",       "load_tag_cur.json",       ["SELECT * FROM TAG"])

    for i, _ in enumerate(campaign_ids, start=1):
        add(f"sql_keyword_{i}.json", f"load_keyword_{i}.json",
            [f"SELECT * FROM SW_CAMP{i} LIMIT 30"])

    # 标准推广 SQL
    add("sql_std_company_cur.json",  "load_std_company_cur.json",  ["SELECT * FROM STD_CUR_COMPANY"])
    add("sql_std_company_prev.json", "load_std_company_prev.json", ["SELECT * FROM STD_PREV_COMPANY"])
    add("sql_std_campaign_cur.json", "load_std_campaign_cur.json", ["SELECT * FROM STD_CUR_CAMP LIMIT 50"])
    add("sql_std_product_cur.json",  "load_std_product_cur.json",  ["SELECT * FROM STD_PROD LIMIT 100"])
    add("sql_std_keyword_cur.json",  "load_std_keyword_cur.json",  ["SELECT * FROM STD_KW LIMIT 50"])

    def run_sql(fname, queries):
        path = os.path.join(out_dir, fname)
        data = mcp_call("icbu_ads_report_execute_sql", {"sqlQueries": queries})
        save(path, data)
        ok = data.get("success") is True
        return fname, ok

    with ThreadPoolExecutor(max_workers=12) as pool:
        futures = [pool.submit(run_sql, f, q) for f, q in sql_tasks]
        for fut in as_completed(futures):
            fname, ok = fut.result()
            print(f"  {'[OK]' if ok else '[FAIL]'} {fname}")


# ─────────────────────────────────────────────
# 主入口
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="P4P 报告数据采集器（支持全自动发现）")
    # 可选 —— 未传则自动从 MCP 获取
    parser.add_argument("--ali-id",       default="",  help="店铺 aliId（留空则自动发现）")
    parser.add_argument("--campaign-ids", default="",  help="活跃计划ID逗号分隔（留空则自动发现）")
    parser.add_argument("--shop-name",    default="",  help="店铺名（留空则自动发现）")
    # 必填
    parser.add_argument("--begin",        required=True, help="当期开始 'YYYY-MM-DD HH:MM:SS'")
    parser.add_argument("--end",          required=True, help="当期结束 'YYYY-MM-DD HH:MM:SS'")
    parser.add_argument("--prev-begin",   required=True, help="上期开始 'YYYY-MM-DD HH:MM:SS'")
    parser.add_argument("--prev-end",     required=True, help="上期结束 'YYYY-MM-DD HH:MM:SS'")
    parser.add_argument("--stat-date",    required=True, help="图片快照日 'YYYY-MM-DD'")
    parser.add_argument("--out-dir",      required=True, help="JSON 输出目录")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    # ── Phase 0: 自动发现（仅在缺少参数时触发）──
    auto_ali_id = args.ali_id.strip()
    auto_campaign_ids = [c.strip() for c in args.campaign_ids.split(",") if c.strip()]
    auto_shop_name = args.shop_name.strip()
    auto_campaign_names = []

    if not auto_ali_id or not auto_campaign_ids:
        discovered_ali, discovered_camps, discovered_names, discovered_shop = auto_discover(args.out_dir)
        if not auto_ali_id:
            auto_ali_id = discovered_ali
        if not auto_campaign_ids:
            auto_campaign_ids = discovered_camps
            auto_campaign_names = discovered_names
        if not auto_shop_name:
            auto_shop_name = discovered_shop

    # 将发现的值写回 args（供 phase1_load 使用）
    args.ali_id = auto_ali_id
    campaign_ids = auto_campaign_ids
    shop_name = auto_shop_name or "MyShop"

    # 保存元信息，供 generate.py 读取（shop_name / campaign_names）
    meta = {
        "ali_id": auto_ali_id,
        "campaign_ids": campaign_ids,
        "campaign_names": auto_campaign_names or [f"计划{c}" for c in campaign_ids],
        "shop_name": shop_name,
        "begin": args.begin,
        "end": args.end,
        "prev_begin": args.prev_begin,
        "prev_end": args.prev_end,
        "stat_date": args.stat_date,
    }
    save(os.path.join(args.out_dir, "meta.json"), meta)

    print("=" * 60)
    print("  P4P 数据采集器")
    print(f"  aliId  : {auto_ali_id}")
    print(f"  店铺   : {shop_name}")
    print(f"  当期   : {args.begin[:10]} ~ {args.end[:10]}")
    print(f"  上期   : {args.prev_begin[:10]} ~ {args.prev_end[:10]}")
    print(f"  计划   : {campaign_ids}")
    print(f"  输出   : {args.out_dir}")
    print("=" * 60)

    t0 = time.time()
    print("\n[Phase 1] 并行 Load datasources...")
    p1 = phase1_load(args, args.out_dir, campaign_ids)
    t1 = time.time()
    ok_cnt = sum(p1.values())
    fail_cnt = sum(1 for v in p1.values() if not v)
    print(f"  Phase 1 耗时: {t1-t0:.1f}s  OK={ok_cnt}  FAIL={fail_cnt}")

    print("\n[Phase 2] 并行 Execute SQL...")
    phase2_sql(args.out_dir, p1, campaign_ids)
    t2 = time.time()
    print(f"  Phase 2 耗时: {t2-t1:.1f}s")

    print(f"\n  采集完成！总耗时: {t2-t0:.1f}s")
    print(f"  数据目录: {args.out_dir}")
    print(f"  店铺名称: {shop_name}  (写入 meta.json，供 generate.py 读取)")


if __name__ == "__main__":
    main()
