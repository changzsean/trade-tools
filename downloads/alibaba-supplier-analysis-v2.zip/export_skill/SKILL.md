---
name: alibaba-supplier-analysis
description: 对阿里巴巴国际站（Alibaba.com）特定行业的供应商进行深度、多维度的竞争分析与背调。支持提取交易量、认证、定制能力及服务响应等多项核心指标。
---

# 阿里巴巴供应商深度分析技能 (Alibaba Supplier Analysis SKILL)

## 概述

通过对阿里巴巴国际站（ICBU）供应商数据的多维度扫描，为用户提供行业竞争格局摸底、Top 供应商画像、以及潜在合作伙伴的深度评估。

## 核心流程

### Step 1: 行业/品类摸底 (Market Discovery)
- **目标**：识别目标市场的主要参与者。
- **操作**：使用 `product_supplier_search` 工具，以行业关键词（如 "Rugged Tablet"）进行供应商维度（`intent_type: "supplier"`）的搜索。

### Step 2: 供应商初步筛选 (Initial Filtering)
- **筛选指标**：
  - **Verified Status**：优先选择经过验证的供应商（Verified Supplier）。
  - **经营年限 (Est. Year)**：优先选择经营 5 年以上的企业。
  - **交易规模 (Transactions)**：分析 Transaction Volume 以判断其实际市场吞吐能力。
  - **响应质量**：关注 Reply Time（建议 ≤ 3h）和 Response Rate（建议 ≥ 90%）。

### Step 3: 多维度画像深度分析 (Supplier Profiling)
提取并对比以下数据点：
- **商业实力**：年营收（Annual Revenue）、员工规模（Staff）、核心产品线。
- **技术能力**：
  - **认证情况**：ISO 9001, CE, FCC, RoHS 以及行业特定认证（如 ATEX, IP68, MIL-STD）。
  - **定制能力 (Customization)**：支持的定制类型（Logo, Packaging, ROM/Software, Hardware Modification）。
- **出口偏好**：主要的出口区域（Export Regions），判断其是否熟悉目标市场的法规。

### Step 4: 自店 vs 标杆对比 (Self-vs-Competitor Benchmarking)
- **数据对齐**：通过 `alibaba-store-analysis` 流程获取自店近 7 天/30 天的核心数据，与 Step 3 筛选出的 Top 3 供应商进行横向对比。
- **对比核心维度**：
  - **流量 (Traffic)**：自店曝光量、点击量 vs 竞对估算流量（基于其 Transactions 和产品数推算）。
  - **广告 (Advertising)**：对比 P4P 推广力度。自店 P4P 曝光占比 vs 竞对在核心关键词上的覆盖广度。
  - **转化 (Conversion)**：自店询盘率 vs 标杆供应商的交易转化（Transactions/Orders 比例）及响应速度。
  - **产品 (Product)**：自店实力优品比例 vs 竞对爆款产品的属性配置（如 2600nits 亮度、军工认证等）。

### Step 5: 差距诊断与提升方向 (Gap Analysis & Optimization)
- **流量缺口分析**：若曝光远低于标杆，诊断是 SEO 关键词缺失还是 P4P 预算及出价竞争力不足。
- **转化瓶颈诊断**：若有点击无询盘，对比竞对详情页的专业度（证书展示、工厂视频、定制流程图）与价格区间。
- **产品力补齐**：根据标杆的 Hot Selling 属性，建议自店产品的升级方向（如增加特定传感器、提升防护等级）。
- **行动计划 (Action Plan)**：
  - **短期**：优化 Top 5 核心产品标题与主图，提升 P4P 精准词点击率。
  - **中期**：补齐标杆具备但自店缺失的行业认证（如 ATEX 认证）。
  - **长期**：建立基于数据反馈的快速测款与上新机制。

### Step 6: 输出结构化报告 (Reporting)
- **对比矩阵 (Benchmarking Matrix)**：

| 核心指标 | 自店数据 | Top 3 标杆均值 | 差距 (Gap) | 提升建议 |
| --- | --- | --- | --- | --- |
| **日均曝光** | {Own_Exp} | {Peer_Exp} | {Gap_Exp}% | 扩充 P4P 关键词库 / 优化 SEO 标题 |
| **平均点击率** | {Own_CTR} | {Peer_CTR} | {Gap_CTR}% | 优化主图视觉对比度 / 增加实力优品标识 |
| **询盘转化率** | {Own_Conv} | {Peer_Conv} | {Gap_Conv}% | 完善详情页 MOQ/价格梯度 / 增加视频演示 |
| **P4P 花费/效果** | {Own_Ads} | {Peer_Ads} | - | 提高精准词出价 / 降低泛词消耗 |
| **实力优品数** | {Own_Prem} | {Peer_Prem} | {Gap_Prem} | 升级 5-10 款潜优产品为实力优品 |

- **优先级行动建议**：
  1. **[紧急]**：针对曝光量缺口，同步标杆 Top 20 流量词。
  2. **[关键]**：优化询盘转化，参考标杆增加“行业认证”与“定制流程”板块。
  3. **[增长]**：根据标杆热销趋势，开发具备 X 特性的新品。

---

## 工具建议

| 阶段 | 建议工具 |
| --- | --- |
| 搜索发现 | `product_supplier_search` |
| 详情补充 | `browser` (访问供应商 Home 页获取更多定制化案例) |
| 报告生成 | `alibaba-com-seller-assistant:office-suite` (生成 PDF/Docx) |

## 示例应用
- **用户需求**："帮我调研一下做三防平板的 Top 供应商，看下谁的定制能力最强。"
- **执行逻辑**：执行 Step 1-3，重点提取 Customization 字段，对比各家支持的接口、系统、外壳定制细项，生成对比报告。
