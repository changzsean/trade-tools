#!/usr/bin/env python3
import subprocess, sys, os, time, json
from pathlib import Path

# V11 SINGULARITY-EXTREME: Orchestrator
# - Multi-store Autopilot Detection
# - Sequential Collection & Reporting
# - Industrial-grade Error Handling

def run_step(cmd, desc):
    print(f">> {desc}...")
    try:
        process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='ignore')
        full_output = []
        for line in process.stdout:
            print(line, end='')
            full_output.append(line)
        process.wait()
        if process.returncode != 0: return None
        return "".join(full_output)
    except Exception as e:
        print(f"Error: {e}")
        return None

def detect_shop_name():
    try:
        # PORTABLE: Try to use accio-mcp-cli from PATH
        cmd = ["accio-mcp-cli", "call", "findCustomerShopInfo", "--json", "{}"]
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore')
        if proc.returncode == 0:
            res = json.loads(proc.stdout)
            name = res.get("result", {}).get("客户店铺基本信息", {}).get("data", {}).get("客户公司名称", "")
            return name if name else "General_Store"
    except: pass
    return "General_Store"

def main():
    root = Path(__file__).parent
    shop_name = detect_shop_name()
    print(f">> 识别到店铺: {shop_name}")
    
    # Store current shop for scripts
    data_dir = root / "data" / "v10_supreme"
    data_dir.mkdir(exist_ok=True, parents=True)
    (data_dir / "current_shop.txt").write_text(shop_name, encoding="utf-8")

    # Step 1: Collect
    collect_out = run_step(f"python {root}/scripts/collect.py", "正在启动 V11 奇点流式采集引擎")
    if not collect_out: return
    
    json_path = ""
    for line in collect_out.split("\n"):
        if "audit_v10_" in line and ".json" in line:
            json_path = line.split("Saved to ")[-1].strip()
            break
            
    if not json_path:
        print("Failed to find result JSON.")
        return
        
    # Step 2: Report
    run_step(f"python {root}/scripts/report.py {json_path}", "正在编译工业级全量审计报表")
    print("V11 SINGULARITY-EXTREME 采集任务完成。")

if __name__ == "__main__":
    main()
