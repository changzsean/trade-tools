#!/usr/bin/env python3
import asyncio, json, subprocess, time, sys, io, argparse, re, hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path

# V11 SINGULARITY-EXTREME: Optimized Data Cycle (Portable Edition)
# - Intelligent Incremental Skip (Only fetch new/updated sessions)
# - Parallel Blasting with Adaptive Semaphore
# - Triple-Source Country Recovery (List, Card-JSON, Profile-API)
# - Global MD5 Message Fingerprinting
# - Industrial-grade Schema Normalization

CST = timezone(timedelta(hours=8))
SEMAPHORE = asyncio.Semaphore(50) 

# DYNAMIC CACHE & INDEX PATHS
SHOP_NAME = "General_Store"
try:
    marker_file = Path("data/v10_supreme/current_shop.txt")
    if marker_file.exists():
        SHOP_NAME = marker_file.read_text(encoding="utf-8").strip()
except: pass

CACHE_FILE = Path(f"data/v10_supreme/{SHOP_NAME}_api_cache.json")
INDEX_FILE = Path(f"data/v10_supreme/{SHOP_NAME}_session_index.json")

CACHE = {}
INDEX = {}

if CACHE_FILE.exists():
    try: CACHE = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except: pass

if INDEX_FILE.exists():
    try: INDEX = json.loads(INDEX_FILE.read_text(encoding="utf-8"))
    except: pass

def save_cache():
    CACHE_FILE.parent.mkdir(exist_ok=True, parents=True)
    CACHE_FILE.write_text(json.dumps(CACHE, ensure_ascii=False), encoding="utf-8")

def save_index():
    INDEX_FILE.parent.mkdir(exist_ok=True, parents=True)
    INDEX_FILE.write_text(json.dumps(INDEX, ensure_ascii=False), encoding="utf-8")

async def call_mcp_async(tool: str, params: dict, use_cache=True):
    key = f"{tool}:{json.dumps(params, sort_keys=True)}"
    if use_cache and key in CACHE: return CACHE[key]
    
    json_str = json.dumps(params, ensure_ascii=False)
    # PORTABLE: Use accio-mcp-cli from PATH
    full_cmd = ["accio-mcp-cli", "call", tool, "--json", json_str]
    try:
        proc = await asyncio.create_subprocess_exec(
            *full_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30.0)
        except asyncio.TimeoutError:
            proc.kill()
            return None
            
        if proc.returncode != 0:
            return None
        res = json.loads(stdout.decode(encoding='utf-8', errors='ignore'))
        if use_cache:
            CACHE[key] = res
            if len(CACHE) % 10 == 0: save_cache()
        return res
    except Exception as e:
        return None

def parse_ts(st: str) -> int:
    if not st: return 0
    if "T" in st:
        try: return int(datetime.fromisoformat(st.replace("Z", "+00:00")).timestamp() * 1000)
        except: pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try: return int(datetime.strptime(st, fmt).replace(tzinfo=CST).timestamp()*1000)
        except: continue
    return 0

def extract_country_from_text(text):
    if not text: return None
    m = re.search(r'"(?:contactCountry|targetCountry)"\s*:\s*"([^"]+)"', text)
    return m.group(1) if m else None

async def fetch_buyer_profile(aliId):
    resp = await call_mcp_async("get_buyer_basic_info", {"contactAliId": int(aliId)})
    obj = (resp or {}).get("object") or {}
    return {
        "country": obj.get("countryCode"),
        "level": obj.get("contactLevel"),
        "profile": obj.get("buyerPortrait")
    }

async def fetch_sessions_v10(aid, floor_ms):
    convs = []
    seen_cids = set()
    cursor = int(time.time() * 1000)
    page = 0
    while page < 500:
        page += 1
        async with SEMAPHORE:
            resp = await call_mcp_async("query_recent_conversation", {
                "request": { "selfAliId": int(aid), "count": 100, "domain": "icbu", "limitTimeStamp": cursor, "forward": False }
            })
        obj = (resp or {}).get("object") or {}
        items = obj.get("conversations") or []
        if not items: break
        last_valid_ts = 0
        for c in items:
            cid = c.get("conversationId")
            st = (c.get("latestMessage") or {}).get("sendTime") or c.get("conversationModifyTime", "")
            ts = parse_ts(st)
            if ts > 0: last_valid_ts = ts
            if cid and cid not in seen_cids:
                seen_cids.add(cid)
                if ts >= floor_ms or ts == 0:
                    country = c.get("contactCountry") or c.get("country")
                    if not country: country = extract_country_from_text(json.dumps(c))
                    target_ali_id = c.get("targetAliId")
                    convs.append({
                        "conversationId": cid, "contactName": c.get("contactName", ""),
                        "contactLevel": c.get("contactLevel", ""), "country": country,
                        "lastActiveTime": st, "ts": ts, "ownerAliId": str(aid),
                        "targetAliId": target_ali_id
                    })
        if not obj.get("hasMore") or (last_valid_ts > 0 and last_valid_ts < floor_ms): break
        cursor = obj.get("nextTimeStamp") or (last_valid_ts - 1 if last_valid_ts > 0 else cursor - 60000)
    return convs

async def fetch_msgs_v10(conv_id, aid, msg_floor):
    msgs = []
    cursor = int(time.time() * 1000)
    for _ in range(30):
        async with SEMAPHORE:
            resp = await call_mcp_async("query_conversation_msg", {
                "request": { "conversationId": conv_id, "selfAliId": int(aid), "count": 50, "limitTimeStamp": cursor, "forward": False }
            })
        obj = (resp or {}).get("object") or {}
        items = obj.get("messages") or []
        if not items: break
        reached_floor = False
        for m in items:
            ts = parse_ts(m.get("sendTime", ""))
            if ts < msg_floor:
                reached_floor = True
                continue
            msgs.append({
                "from": "seller" if str(m.get("senderAliId")) == str(aid) else "buyer",
                "time": m.get("sendTime", ""), "text": m.get("content", ""), 
                "msgId": m.get("msgId"), "senderAliId": m.get("senderAliId"), "isSystem": m.get("isSystemMessage", False)
            })
        if reached_floor or not obj.get("hasMore"): break
        cursor = obj.get("nextPointTimeStamp") or cursor
    return msgs[::-1]

async def process_account_v10(aid, name, sess_floor, msg_floor):
    print(f"  [PROCESS] Account {name} ({aid}) ...")
    convs = await fetch_sessions_v10(aid, sess_floor)
    active_convs = [c for c in convs if c["ts"] >= msg_floor]
    to_fetch = []
    for c in active_convs:
        cid = c["conversationId"]
        if c["ts"] > INDEX.get(cid, 0): to_fetch.append(c)
    print(f"    - {name}: {len(to_fetch)} sessions to sync ({len(active_convs)} total active)")
    recovery_tasks = [fetch_buyer_profile(c["targetAliId"]) if not c["country"] and c["targetAliId"] else asyncio.sleep(0, result=None) for c in to_fetch]
    profiles = await asyncio.gather(*recovery_tasks)
    for i, p in enumerate(profiles):
        if p:
            to_fetch[i]["country"] = p.get("country") or to_fetch[i]["country"]
            to_fetch[i]["contactLevel"] = p.get("level") or to_fetch[i]["contactLevel"]
    msg_results = []
    chunk_size = 30
    for i in range(0, len(to_fetch), chunk_size):
        chunk = to_fetch[i:i+chunk_size]
        tasks = [fetch_msgs_v10(c["conversationId"], aid, msg_floor) for c in chunk]
        chunk_res = await asyncio.gather(*tasks)
        msg_results.extend(chunk_res)
    for i, c in enumerate(to_fetch):
        c["messages"] = msg_results[i]
        INDEX[c["conversationId"]] = c["ts"]
        if not c["country"]:
            for m in c["messages"]:
                found = extract_country_from_text(m["text"])
                if found: c["country"] = found; break
    save_index()
    return convs

async def get_all_accounts():
    resp = await call_mcp_async("subaccount_query", {"request": {"selfAliId": None}})
    data = (resp or {}).get("data") or []
    return {str(i["aliId"]): f"{i['firstName']} {i['lastName']}".strip() for i in data}

async def main():
    mapping = await get_all_accounts()
    print(f">> Mapped {len(mapping)} sub-accounts.")
    now_ms = int(time.time() * 1000)
    sess_floor = now_ms - (60 * 24 * 3600 * 1000) 
    msg_floor = now_ms - (30 * 24 * 3600 * 1000)
    all_results = await asyncio.gather(*[process_account_v10(aid, name, sess_floor, msg_floor) for aid, name in mapping.items()])
    flat_convs = [item for sub in all_results for item in sub]
    conv_map = {}
    for c in flat_convs:
        cid = c["conversationId"]
        if cid not in conv_map: conv_map[cid] = c
        else:
            if not conv_map[cid]["country"] and c["country"]: conv_map[cid]["country"] = c["country"]
            if len(c.get("messages", [])) > len(conv_map[cid].get("messages", [])): conv_map[cid]["messages"] = c["messages"]
    final_data = {"meta": {"timestamp": datetime.now(CST).isoformat(), "count": len(conv_map)}, "accounts": mapping, "data": list(conv_map.values())}
    Path("data/v10_supreme").mkdir(exist_ok=True, parents=True)
    out_file = Path(f"data/v10_supreme/audit_v10_{int(time.time())}.json")
    out_file.write_text(json.dumps(final_data, ensure_ascii=False), encoding="utf-8")
    print(f">> V11 AUDIT COMPLETE: {len(conv_map)} sessions. Saved to {out_file}")

if __name__ == "__main__":
    asyncio.run(main())
