import json, pandas as pd, time, os, re, sys
from pathlib import Path
from datetime import datetime

# V11 INDUSTRIAL REPORTER: Multi-sheet Excel Generator
# - Auto Shop Identification
# - Multi-sheet Summary (Stats, 180d List, 30d Msg)
# - Dark Header Styling & Auto-filter

CST_OFFSET = 8

def parse_ts(st):
    try: return int(datetime.fromisoformat(st.replace("Z", "+00:00")).timestamp())
    except: return 0

def format_report():
    if len(sys.argv) < 2: return
    input_json = Path(sys.argv[1])
    if not input_json.exists(): return
    
    raw = json.loads(input_json.read_text(encoding="utf-8"))
    data = raw.get("data", [])
    
    # Session List Sheet
    df_sessions = pd.DataFrame([{
        "业务员": raw["accounts"].get(c["ownerAliId"], c["ownerAliId"]),
        "联系人": c["contactName"],
        "等级": c["contactLevel"],
        "国家": c["country"],
        "最后活跃时间": c["lastActiveTime"],
        "状态": "30天内活跃" if len(c.get("messages", [])) > 0 else "仅历史会话"
    } for c in data])

    # Message Detail Sheet
    msg_rows = []
    for c in data:
        for m in c.get("messages", []):
            msg_rows.append({
                "时间": m["time"],
                "业务员": raw["accounts"].get(c["ownerAliId"], c["ownerAliId"]),
                "买家": c["contactName"],
                "发送方": "业务员" if m["from"] == "seller" else "买家",
                "内容": m["text"],
                "国家": c["country"]
            })
    df_msgs = pd.DataFrame(msg_rows)

    if not df_msgs.empty:
        df_msgs = df_msgs.drop_duplicates(subset=["时间", "业务员", "内容"])
        df_msgs = df_msgs.sort_values(by="时间", ascending=False)

    # Analytics Sheet
    if not df_sessions.empty:
        summary = df_sessions.groupby('业务员').agg({
            '联系人': 'count',
            '国家': 'nunique',
            '状态': lambda x: (x == '30天内活跃').sum()
        }).rename(columns={'联系人': '180天总会话', '国家': '覆盖国家数', '状态': '30天活跃询盘'})
    else:
        summary = pd.DataFrame()

    # DYNAMIC SHOP IDENTIFICATION
    shop_name = "General_Store"
    try:
        marker_file = Path("data/v10_supreme/current_shop.txt")
        if marker_file.exists():
            shop_name = marker_file.read_text(encoding="utf-8").strip()
    except: pass

    # Path Setup
    timestamp = int(time.time())
    output_name = f"alibaba_chat_V11_Supreme_Audit_{timestamp}.xlsx"
    
    # Try E: Drive First
    primary_base = Path(r"E:\Accio Work单独资料库\Accio Work-finish")
    primary_path = primary_base / shop_name
    
    if primary_base.exists():
        primary_path.mkdir(parents=True, exist_ok=True)
        final_xlsx = primary_path / output_name
    else:
        # Fallback to local deliverables folder
        fallback_path = Path(f"./deliverables/{shop_name}")
        fallback_path.mkdir(parents=True, exist_ok=True)
        final_xlsx = fallback_path / output_name

    with pd.ExcelWriter(final_xlsx, engine='openpyxl') as writer:
        if not summary.empty:
            summary.to_excel(writer, sheet_name='数据概览')
        else:
            # Create a placeholder if empty
            pd.DataFrame([{"提示": "本次采集未发现活跃数据"}]).to_excel(writer, sheet_name='数据概览', index=False)
            
        if not df_sessions.empty: df_sessions.to_excel(writer, sheet_name='180天会话清单', index=False)
        if not df_msgs.empty: df_msgs.to_excel(writer, sheet_name='30天全量消息明细', index=False)

    print(f"REPORT_SUCCESS: {final_xlsx.absolute()}")

if __name__ == "__main__":
    format_report()
